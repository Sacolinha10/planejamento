/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { FinanceProvider, useFinance } from './context/FinanceContext';
import { Header } from './components/Header';
import { MonthSelector } from './components/MonthSelector';
import { NavigationTabs, ActiveTab } from './components/NavigationTabs';
import { OverviewView } from './components/OverviewView';
import { BudgetPlanView } from './components/BudgetPlanView';
import { IncomeExpensesView } from './components/IncomeExpensesView';
import { TransactionsView } from './components/TransactionsView';
import { AnnualView } from './components/AnnualView';
import { TransactionModal } from './components/TransactionModal';
import { BudgetItemModal } from './components/BudgetItemModal';
import { ExtraDebtModal } from './components/ExtraDebtModal';
import { CopyBudgetModal } from './components/CopyBudgetModal';
import { BudgetItem, FinanceGroup } from './types/finance';

function MainApp() {
  const { currentMonthBudget, setSelectedMonth } = useFinance();
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');

  // Modais
  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false);
  const [isBudgetItemModalOpen, setIsBudgetItemModalOpen] = useState(false);
  const [budgetModalGroup, setBudgetModalGroup] = useState<FinanceGroup>('variable');
  const [extraDebtItem, setExtraDebtItem] = useState<BudgetItem | null>(null);
  const [isCopyModalOpen, setIsCopyModalOpen] = useState(false);

  const handleOpenBudgetItemModal = (group: FinanceGroup = 'variable') => {
    setBudgetModalGroup(group);
    setIsBudgetItemModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col text-neutral-900 font-sans">
      {/* 1. Barra de Topo Principal */}
      <Header
        onOpenNewTransaction={() => setIsTransactionModalOpen(true)}
        onOpenNewBudgetItem={() => handleOpenBudgetItemModal('variable')}
      />

      {/* 2. Seletor de Meses (Janeiro a Dezembro) */}
      <MonthSelector onOpenCopyModal={() => setIsCopyModalOpen(true)} />

      {/* 3. Navegação entre Abas */}
      <NavigationTabs
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        transactionsCount={currentMonthBudget.transactions.length}
      />

      {/* 4. Conteúdo Principal */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'overview' && (
          <OverviewView
            onGoToBudget={() => setActiveTab('budget')}
            onGoToTransactions={() => setActiveTab('transactions')}
            onOpenNewTransaction={() => setIsTransactionModalOpen(true)}
          />
        )}

        {activeTab === 'budget' && (
          <BudgetPlanView
            onOpenNewItem={handleOpenBudgetItemModal}
            onOpenExtraDebtModal={(item) => setExtraDebtItem(item)}
          />
        )}

        {activeTab === 'cashflow' && (
          <IncomeExpensesView />
        )}

        {activeTab === 'transactions' && (
          <TransactionsView
            onOpenNewTransaction={() => setIsTransactionModalOpen(true)}
          />
        )}

        {activeTab === 'annual' && (
          <AnnualView
            onSelectMonth={(month) => {
              setSelectedMonth(month);
              setActiveTab('overview');
            }}
          />
        )}
      </main>

      {/* Rodapé Clean */}
      <footer className="bg-white border-t border-neutral-200 py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-500 gap-2">
          <div>
            <span>FinPlan · Sistema de Planejamento Financeiro Pessoal</span>
          </div>
          <div className="flex items-center gap-4">
            <span>Orçamento Previsto vs Realizado</span>
            <span>·</span>
            <span>Janeiro a Dezembro</span>
          </div>
        </div>
      </footer>

      {/* Modais de Interação */}
      <TransactionModal
        isOpen={isTransactionModalOpen}
        onClose={() => setIsTransactionModalOpen(false)}
      />

      <BudgetItemModal
        isOpen={isBudgetItemModalOpen}
        onClose={() => setIsBudgetItemModalOpen(false)}
        defaultGroup={budgetModalGroup}
      />

      <ExtraDebtModal
        item={extraDebtItem}
        onClose={() => setExtraDebtItem(null)}
      />

      <CopyBudgetModal
        isOpen={isCopyModalOpen}
        onClose={() => setIsCopyModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <FinanceProvider>
      <MainApp />
    </FinanceProvider>
  );
}
