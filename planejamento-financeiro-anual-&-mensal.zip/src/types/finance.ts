export type MonthIndex = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11;

export const MONTH_NAMES: { [key in MonthIndex]: string } = {
  0: 'Janeiro',
  1: 'Fevereiro',
  2: 'Março',
  3: 'Abril',
  4: 'Maio',
  5: 'Junho',
  6: 'Julho',
  7: 'Agosto',
  8: 'Setembro',
  9: 'Outubro',
  10: 'Novembro',
  11: 'Dezembro',
};

export const MONTH_SHORT_NAMES: { [key in MonthIndex]: string } = {
  0: 'Jan',
  1: 'Fev',
  2: 'Mar',
  3: 'Abr',
  4: 'Mai',
  5: 'Jun',
  6: 'Jul',
  7: 'Ago',
  8: 'Set',
  9: 'Out',
  10: 'Nov',
  11: 'Dez',
};

export type FinanceGroup = 'income' | 'fixed' | 'variable' | 'savings' | 'debt';

export interface BudgetItem {
  id: string;
  name: string;
  category: string;
  group: FinanceGroup;
  planned: number; // Valor orçado / previsto
  actual: number;  // Valor realizado / saída real calculada ou registrada
  isCustom?: boolean; // Para categorias criadas pelo usuário
  notes?: string;
  extraPayment?: number; // Para dívidas: amortização / pagamento extra
  totalDebt?: number;    // Para dívidas: saldo devedor restante total
}

export type PaymentMethod = 'pix' | 'credit_card' | 'debit_card' | 'bank_slip' | 'transfer' | 'cash';

export interface Transaction {
  id: string;
  date: string; // YYYY-MM-DD
  month: MonthIndex;
  year: number;
  type: 'income' | 'expense';
  group: FinanceGroup;
  category: string;
  description: string;
  amount: number;
  paymentMethod: PaymentMethod;
  status: 'paid' | 'pending';
  budgetItemId?: string;
}

export interface MonthlyBudget {
  month: MonthIndex;
  year: number;
  items: BudgetItem[];
  transactions: Transaction[];
}

export interface MonthSummary {
  // Receitas
  incomePlanned: number;
  incomeActual: number;
  incomeDifference: number;

  // Despesas Fixas
  fixedPlanned: number;
  fixedActual: number;
  fixedDifference: number;

  // Despesas Variáveis
  variablePlanned: number;
  variableActual: number;
  variableDifference: number;

  // Economias / Investimentos
  savingsPlanned: number;
  savingsActual: number;
  savingsDifference: number;

  // Dívidas & Empréstimos
  debtPlanned: number;
  debtActual: number;
  debtExtraPaid: number;
  debtDifference: number;

  // Totais de Saídas (Fixas + Variáveis + Dívidas)
  totalExpensesPlanned: number;
  totalExpensesActual: number;

  // Total Geral Comprometido (Despesas + Economias)
  totalOutflowPlanned: number;
  totalOutflowActual: number;

  // Disponibilidade de Recursos
  // 1. Orçamento Disponível = Receitas Previstas - Total Orçado
  availableBudget: number;
  
  // 2. Disponível para Gastar = Entradas Reais - Saídas Reais (incluindo economias e dívidas pagas)
  availableToSpend: number;

  // 3. Saldo Livre de Gastos = Orçado para Gastar (Variáveis + Fixas) - Gasto Real (Variáveis + Fixas)
  budgetRemainingToSpend: number;

  // Taxa de Poupança Realizada (%)
  savingsRate: number;
}
