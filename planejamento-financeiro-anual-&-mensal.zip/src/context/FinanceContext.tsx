import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  BudgetItem,
  MonthIndex,
  MonthlyBudget,
  MonthSummary,
  Transaction,
} from '../types/finance';
import { calculateSummary, formatDateBR, formatCurrency } from '../utils/formatters';
import { generateInitialYearData } from '../utils/initialData';

interface FinanceContextType {
  year: number;
  setYear: (year: number) => void;
  selectedMonth: MonthIndex;
  setSelectedMonth: (month: MonthIndex) => void;
  monthlyBudgets: MonthlyBudget[];
  currentMonthBudget: MonthlyBudget;
  currentSummary: MonthSummary;
  allMonthsSummaries: MonthSummary[];
  
  // Ações de itens de orçamento
  addBudgetItem: (item: Omit<BudgetItem, 'id'>) => void;
  updateBudgetItem: (item: BudgetItem) => void;
  deleteBudgetItem: (id: string) => void;
  
  // Ações de transações
  addTransaction: (tx: Omit<Transaction, 'id'>) => void;
  updateTransaction: (tx: Transaction) => void;
  deleteTransaction: (id: string) => void;
  
  // Ferramentas úteis
  copyBudgetFromMonth: (sourceMonth: MonthIndex, targetMonth: MonthIndex) => void;
  resetToDefaults: () => void;
  exportJSON: () => void;
  importJSON: (jsonStr: string) => boolean;
  exportCSV: () => void;
}

const STORAGE_KEY = 'planejamento_financeiro_anual_v1';

const FinanceContext = createContext<FinanceContextType | undefined>(undefined);

export const FinanceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [year, setYear] = useState<number>(() => new Date().getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<MonthIndex>(() => {
    const cur = new Date().getMonth();
    return (cur >= 0 && cur <= 11 ? cur : 0) as MonthIndex;
  });

  const [monthlyBudgets, setMonthlyBudgets] = useState<MonthlyBudget[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length === 12) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Erro ao carregar dados salvos, usando template inicial:', e);
    }
    return generateInitialYearData(new Date().getFullYear());
  });

  // Salvar no localStorage sempre que houver modificações
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(monthlyBudgets));
    } catch (err) {
      console.error('Falha ao persistir no localStorage:', err);
    }
  }, [monthlyBudgets]);

  const currentMonthBudget =
    monthlyBudgets.find((m) => m.month === selectedMonth) ||
    monthlyBudgets[0] || {
      month: selectedMonth,
      year,
      items: [],
      transactions: [],
    };

  const currentSummary = calculateSummary(
    currentMonthBudget.items,
    currentMonthBudget.transactions
  );

  const allMonthsSummaries = monthlyBudgets.map((mb) =>
    calculateSummary(mb.items, mb.transactions)
  );

  // Manipulação de Itens de Orçamento
  const addBudgetItem = (itemData: Omit<BudgetItem, 'id'>) => {
    const newItem: BudgetItem = {
      ...itemData,
      id: `item-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    };

    setMonthlyBudgets((prev) =>
      prev.map((mb) => {
        if (mb.month === selectedMonth) {
          return {
            ...mb,
            items: [...mb.items, newItem],
          };
        }
        return mb;
      })
    );
  };

  const updateBudgetItem = (updatedItem: BudgetItem) => {
    setMonthlyBudgets((prev) =>
      prev.map((mb) => {
        if (mb.month === selectedMonth) {
          return {
            ...mb,
            items: mb.items.map((it) => (it.id === updatedItem.id ? updatedItem : it)),
          };
        }
        return mb;
      })
    );
  };

  const deleteBudgetItem = (id: string) => {
    setMonthlyBudgets((prev) =>
      prev.map((mb) => {
        if (mb.month === selectedMonth) {
          return {
            ...mb,
            items: mb.items.filter((it) => it.id !== id),
            // Se houver transações vinculadas, desvincula o item
            transactions: mb.transactions.map((tx) =>
              tx.budgetItemId === id ? { ...tx, budgetItemId: undefined } : tx
            ),
          };
        }
        return mb;
      })
    );
  };

  // Manipulação de Transações
  const addTransaction = (txData: Omit<Transaction, 'id'>) => {
    const newTx: Transaction = {
      ...txData,
      id: `tx-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    };

    setMonthlyBudgets((prev) =>
      prev.map((mb) => {
        if (mb.month === txData.month) {
          // Atualiza também o actual do item orçamentário se houver vínculo
          let updatedItems = mb.items;
          if (newTx.budgetItemId && newTx.status === 'paid') {
            updatedItems = mb.items.map((it) => {
              if (it.id === newTx.budgetItemId) {
                return {
                  ...it,
                  actual: (it.actual || 0) + newTx.amount,
                };
              }
              return it;
            });
          }

          return {
            ...mb,
            items: updatedItems,
            transactions: [newTx, ...mb.transactions],
          };
        }
        return mb;
      })
    );
  };

  const updateTransaction = (updatedTx: Transaction) => {
    setMonthlyBudgets((prev) =>
      prev.map((mb) => {
        if (mb.month === updatedTx.month) {
          return {
            ...mb,
            transactions: mb.transactions.map((t) =>
              t.id === updatedTx.id ? updatedTx : t
            ),
          };
        }
        return mb;
      })
    );
  };

  const deleteTransaction = (id: string) => {
    setMonthlyBudgets((prev) =>
      prev.map((mb) => {
        if (mb.month === selectedMonth) {
          return {
            ...mb,
            transactions: mb.transactions.filter((t) => t.id !== id),
          };
        }
        return mb;
      })
    );
  };

  const copyBudgetFromMonth = (sourceMonth: MonthIndex, targetMonth: MonthIndex) => {
    const source = monthlyBudgets.find((mb) => mb.month === sourceMonth);
    if (!source) return;

    setMonthlyBudgets((prev) =>
      prev.map((mb) => {
        if (mb.month === targetMonth) {
          const clonedItems = source.items.map((it) => ({
            ...it,
            id: `m${targetMonth}-clone-${Math.random().toString(36).substring(2, 8)}`,
            actual: 0, // Inicia novo mês com saídas zeradas
            extraPayment: 0,
          }));
          return {
            ...mb,
            items: clonedItems,
          };
        }
        return mb;
      })
    );
  };

  const resetToDefaults = () => {
    const defaults = generateInitialYearData(year);
    setMonthlyBudgets(defaults);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(defaults));
  };

  const exportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(monthlyBudgets, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `planejamento_financeiro_${year}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const importJSON = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr);
      if (Array.isArray(parsed) && parsed.length === 12) {
        setMonthlyBudgets(parsed);
        return true;
      }
    } catch (e) {
      console.error(e);
    }
    return false;
  };

  const exportCSV = () => {
    const rows = [
      ['Mês', 'Data', 'Tipo', 'Grupo', 'Categoria', 'Descrição', 'Valor (R$)', 'Forma de Pagamento', 'Status'],
    ];

    monthlyBudgets.forEach((mb) => {
      mb.transactions.forEach((tx) => {
        rows.push([
          String(mb.month + 1),
          formatDateBR(tx.date),
          tx.type === 'income' ? 'Entrada' : 'Saída',
          tx.group,
          `"${tx.category}"`,
          `"${tx.description}"`,
          tx.amount.toFixed(2).replace('.', ','),
          tx.paymentMethod,
          tx.status === 'paid' ? 'Efetivado' : 'Pendente',
        ]);
      });
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map((e) => e.join(';')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `transacoes_financeiras_${year}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  return (
    <FinanceContext.Provider
      value={{
        year,
        setYear,
        selectedMonth,
        setSelectedMonth,
        monthlyBudgets,
        currentMonthBudget,
        currentSummary,
        allMonthsSummaries,
        addBudgetItem,
        updateBudgetItem,
        deleteBudgetItem,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        copyBudgetFromMonth,
        resetToDefaults,
        exportJSON,
        importJSON,
        exportCSV,
      }}
    >
      {children}
    </FinanceContext.Provider>
  );
};

export const useFinance = () => {
  const context = useContext(FinanceContext);
  if (!context) {
    throw new Error('useFinance deve ser usado dentro de um FinanceProvider');
  }
  return context;
};
