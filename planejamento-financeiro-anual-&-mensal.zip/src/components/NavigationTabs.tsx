import React from 'react';
import {
  BarChart3,
  Layers,
  ArrowLeftRight,
  CalendarDays,
  Scale,
} from 'lucide-react';

export type ActiveTab = 'overview' | 'budget' | 'cashflow' | 'transactions' | 'annual';

interface NavigationTabsProps {
  activeTab: ActiveTab;
  onChangeTab: (tab: ActiveTab) => void;
  transactionsCount: number;
}

export const NavigationTabs: React.FC<NavigationTabsProps> = ({
  activeTab,
  onChangeTab,
  transactionsCount,
}) => {
  const tabs = [
    {
      id: 'overview' as ActiveTab,
      label: 'Aba "Total" (Visão Geral)',
      subtitle: 'Panorama consolidado',
      icon: BarChart3,
    },
    {
      id: 'budget' as ActiveTab,
      label: 'Orçamento Mensal',
      subtitle: 'Receitas, Fixas, Variáveis, Dívidas',
      icon: Layers,
    },
    {
      id: 'cashflow' as ActiveTab,
      label: 'Receitas & Despesas',
      subtitle: 'Raio-X e comparativo',
      icon: Scale,
    },
    {
      id: 'transactions' as ActiveTab,
      label: 'Aba "Transações"',
      subtitle: `${transactionsCount} lançamentos`,
      icon: ArrowLeftRight,
    },
    {
      id: 'annual' as ActiveTab,
      label: 'Visão Anual (Jan - Dez)',
      subtitle: 'Todos os 12 meses',
      icon: CalendarDays,
    },
  ];

  return (
    <div className="bg-white border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex space-x-1 sm:space-x-4 overflow-x-auto py-2 scrollbar-none" aria-label="Abas de Navegação">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => onChangeTab(tab.id)}
                className={`flex items-center gap-2 py-2 px-3 sm:px-4 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-neutral-900 text-white'
                    : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-neutral-500'}`} />
                <span>{tab.label}</span>
                <span className={`text-[11px] ${isActive ? 'text-neutral-300' : 'text-neutral-400'} hidden lg:inline`}>
                  ({tab.subtitle})
                </span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
};
