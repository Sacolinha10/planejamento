import React from 'react';
import { useFinance } from '../context/FinanceContext';
import { MONTH_NAMES, MONTH_SHORT_NAMES, MonthIndex } from '../types/finance';
import { formatCurrency, formatPercent } from '../utils/formatters';
import {
  TrendingUp,
  Wallet,
  PiggyBank,
  CreditCard,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Zap,
  LineChart as LineChartIcon,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';

interface OverviewViewProps {
  onGoToBudget: () => void;
  onGoToTransactions: () => void;
  onOpenNewTransaction: () => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  onGoToBudget,
  onGoToTransactions,
  onOpenNewTransaction,
}) => {
  const {
    currentSummary,
    selectedMonth,
    setSelectedMonth,
    year,
    currentMonthBudget,
    allMonthsSummaries,
  } = useFinance();

  // Dados formatados para o gráfico de linhas Recharts ao longo dos 12 meses
  const chartData = allMonthsSummaries.map((summary, idx) => {
    const monthShort = MONTH_SHORT_NAMES[idx as MonthIndex];
    const monthFull = MONTH_NAMES[idx as MonthIndex];
    const receitas = summary.incomeActual;
    const despesas =
      summary.fixedActual +
      summary.variableActual +
      summary.debtActual +
      summary.debtExtraPaid;
    const saldo = summary.availableToSpend;

    return {
      month: monthShort,
      fullName: monthFull,
      monthIndex: idx,
      Receitas: receitas,
      Despesas: despesas,
      Saldo: saldo,
    };
  });

  const CustomChartTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const dataItem = payload[0].payload;
      return (
        <div className="bg-white/95 backdrop-blur-xs border border-neutral-200 rounded-lg p-3 shadow-lg text-xs space-y-1.5 min-w-48 z-50">
          <div className="font-bold text-neutral-900 border-b border-neutral-100 pb-1 flex items-center justify-between">
            <span>{dataItem.fullName} {year}</span>
            <span className="text-[10px] text-neutral-400 font-normal">Mês {dataItem.monthIndex + 1}</span>
          </div>
          {payload.map((entry: any, index: number) => (
            <div key={`item-${index}`} className="flex items-center justify-between gap-3">
              <span className="flex items-center gap-1.5 text-neutral-600">
                <span
                  className="w-2 h-2 rounded-full inline-block"
                  style={{ backgroundColor: entry.color }}
                />
                <span>{entry.name}:</span>
              </span>
              <span
                className={`font-mono font-semibold ${
                  entry.name === 'Saldo'
                    ? entry.value >= 0
                      ? 'text-blue-700'
                      : 'text-rose-600'
                    : 'text-neutral-900'
                }`}
              >
                {formatCurrency(entry.value)}
              </span>
            </div>
          ))}
          <div className="pt-1 border-t border-neutral-100 text-[10px] text-neutral-400">
            Clique no ponto para selecionar o mês
          </div>
        </div>
      );
    }
    return null;
  };

  const {
    incomePlanned,
    incomeActual,
    incomeDifference,
    fixedPlanned,
    fixedActual,
    fixedDifference,
    variablePlanned,
    variableActual,
    variableDifference,
    savingsPlanned,
    savingsActual,
    debtPlanned,
    debtActual,
    debtExtraPaid,
    totalExpensesPlanned,
    totalExpensesActual,
    totalOutflowPlanned,
    totalOutflowActual,
    availableBudget,
    availableToSpend,
    budgetRemainingToSpend,
    savingsRate,
  } = currentSummary;

  // Percentuais de execução
  const incomePct = incomePlanned > 0 ? (incomeActual / incomePlanned) * 100 : 0;
  const fixedPct = fixedPlanned > 0 ? (fixedActual / fixedPlanned) * 100 : 0;
  const variablePct = variablePlanned > 0 ? (variableActual / variablePlanned) * 100 : 0;
  const savingsPct = savingsPlanned > 0 ? (savingsActual / savingsPlanned) * 100 : 0;
  const debtPct = debtPlanned > 0 ? ((debtActual + debtExtraPaid) / debtPlanned) * 100 : 0;

  // Grupos consolidados para a tabela resumo
  const summaryRows = [
    {
      group: 'Receitas (Entradas)',
      planned: incomePlanned,
      actual: incomeActual,
      diff: incomeActual - incomePlanned,
      isFavorable: incomeActual >= incomePlanned,
      pct: incomePct,
      type: 'income',
      description: 'Salários, rendimentos e rendas extras',
    },
    {
      group: 'Despesas Fixas',
      planned: fixedPlanned,
      actual: fixedActual,
      diff: fixedPlanned - fixedActual, // Positivo = gastou menos que o orçado
      isFavorable: fixedActual <= fixedPlanned,
      pct: fixedPct,
      type: 'expense',
      description: 'Moradia, energia, telecom e planos essenciais',
    },
    {
      group: 'Despesas Variáveis',
      planned: variablePlanned,
      actual: variableActual,
      diff: variablePlanned - variableActual, // Positivo = sobrou orçamento
      isFavorable: variableActual <= variablePlanned,
      pct: variablePct,
      type: 'expense',
      description: 'Supermercado, combustível, refeições e compras',
    },
    {
      group: 'Dívidas & Empréstimos',
      planned: debtPlanned,
      actual: debtActual + debtExtraPaid,
      diff: debtPlanned - (debtActual + debtExtraPaid),
      isFavorable: debtExtraPaid > 0 ? true : debtActual <= debtPlanned,
      pct: debtPct,
      type: 'expense',
      description: `Parcelas regulares + ${formatCurrency(debtExtraPaid)} em amortizações extras`,
    },
    {
      group: 'Economias & Investimentos',
      planned: savingsPlanned,
      actual: savingsActual,
      diff: savingsActual - savingsPlanned,
      isFavorable: savingsActual >= savingsPlanned,
      pct: savingsPct,
      type: 'savings',
      description: 'Reserva de emergência, ações e metas de futuro',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Bloco 1: KPIs & Disponibilidade de Recursos */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Receitas (Previstas vs Entraram) */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-neutral-500">
              Receitas Realizadas
            </span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold font-mono tracking-tight text-neutral-900">
            {formatCurrency(incomeActual)}
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-neutral-500">
            <span>Previsto: {formatCurrency(incomePlanned)}</span>
            <span
              className={`font-mono font-medium ${
                incomeDifference >= 0 ? 'text-emerald-600' : 'text-rose-600'
              }`}
            >
              {incomeDifference >= 0 ? '+' : ''}
              {formatCurrency(incomeDifference)}
            </span>
          </div>
          <div className="mt-2 w-full bg-neutral-100 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-emerald-500 h-full rounded-full transition-all duration-300"
              style={{ width: `${Math.min(incomePct, 100)}%` }}
            />
          </div>
        </div>

        {/* Card 2: Disponível para Gastar (Saldo Real em Conta) */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-neutral-500">
              Disponível para Gastar
            </span>
            <Wallet className="w-4 h-4 text-blue-600" />
          </div>
          <div
            className={`text-2xl font-bold font-mono tracking-tight ${
              availableToSpend >= 0 ? 'text-neutral-900' : 'text-rose-600'
            }`}
          >
            {formatCurrency(availableToSpend)}
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-neutral-500">
            <span>Entradas - Saídas Reais</span>
            <span className="font-mono text-neutral-700 font-medium">
              {availableToSpend >= 0 ? 'Superávit' : 'Déficit'}
            </span>
          </div>
          <p className="mt-2 text-[11px] text-neutral-400">
            Saldo livre que restou na sua conta bancária após todos os pagamentos.
          </p>
        </div>

        {/* Card 3: Orçamento Restante de Gastos */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-neutral-500">
              Resta do Orçamento
            </span>
            <ShieldCheck className="w-4 h-4 text-indigo-600" />
          </div>
          <div
            className={`text-2xl font-bold font-mono tracking-tight ${
              budgetRemainingToSpend >= 0 ? 'text-indigo-600' : 'text-rose-600'
            }`}
          >
            {formatCurrency(budgetRemainingToSpend)}
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-neutral-500">
            <span>Fixas + Variáveis</span>
            <span className="font-mono text-neutral-600">
              {budgetRemainingToSpend >= 0 ? 'Sobrando' : 'Estourado'}
            </span>
          </div>
          <p className="mt-2 text-[11px] text-neutral-400">
            Margem disponível de gastos antes de atingir o teto orçado do mês.
          </p>
        </div>

        {/* Card 4: Economias & Amortizações */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-neutral-500">
              Poupança & Amortização
            </span>
            <PiggyBank className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold font-mono tracking-tight text-neutral-900">
            {formatCurrency(savingsActual + debtExtraPaid)}
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-neutral-500">
            <span>Taxa de Poupança</span>
            <span className="font-mono font-medium text-emerald-600">
              {formatPercent(savingsRate)}
            </span>
          </div>
          <p className="mt-2 text-[11px] text-neutral-400">
            {debtExtraPaid > 0
              ? `Inclui ${formatCurrency(debtExtraPaid)} em amortização extra de dívidas`
              : 'Destinado a reservas e patrimônio futuro'}
          </p>
        </div>
      </div>

      {/* Bloco: Gráfico Recharts de Evolução do Saldo, Receitas e Despesas */}
      <div className="bg-white border border-neutral-200 rounded-xl p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-6">
          <div>
            <h3 className="text-base font-bold text-neutral-900 flex items-center gap-2">
              <LineChartIcon className="w-5 h-5 text-emerald-600" />
              <span>Evolução Anual: Saldo, Receitas e Despesas ({year})</span>
            </h3>
            <p className="text-xs text-neutral-500">
              Trajetória comparativa mês a mês de Janeiro a Dezembro. Clique em qualquer mês do gráfico para selecioná-lo.
            </p>
          </div>

          {/* Destaque do Mês Ativo */}
          <div className="flex items-center gap-3 bg-neutral-50 px-3.5 py-2 rounded-lg border border-neutral-200 text-xs self-start md:self-auto">
            <span className="text-neutral-500 font-medium">{MONTH_NAMES[selectedMonth]}:</span>
            <div className="flex items-center gap-3">
              <span className="font-mono text-emerald-700 font-semibold" title="Receita Realizada">
                +{formatCurrency(incomeActual)}
              </span>
              <span className="text-neutral-300">|</span>
              <span className="font-mono text-rose-600 font-semibold" title="Despesas Totais">
                -{formatCurrency(fixedActual + variableActual + debtActual + debtExtraPaid)}
              </span>
              <span className="text-neutral-300">|</span>
              <span
                className={`font-mono font-bold ${
                  availableToSpend >= 0 ? 'text-blue-700' : 'text-rose-600'
                }`}
                title="Saldo Disponível"
              >
                Saldo: {formatCurrency(availableToSpend)}
              </span>
            </div>
          </div>
        </div>

        {/* Componente Recharts LineChart */}
        <div className="w-full h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={chartData}
              margin={{ top: 10, right: 20, left: 0, bottom: 5 }}
              onClick={(e) => {
                if (e && e.activeTooltipIndex !== undefined) {
                  setSelectedMonth(e.activeTooltipIndex as MonthIndex);
                }
              }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis
                dataKey="month"
                stroke="#94a3b8"
                tick={{ fontSize: 12, fill: '#64748b' }}
                tickLine={false}
                axisLine={{ stroke: '#e2e8f0' }}
              />
              <YAxis
                stroke="#94a3b8"
                tick={{ fontSize: 11, fill: '#64748b' }}
                tickLine={false}
                axisLine={{ stroke: '#e2e8f0' }}
                tickFormatter={(val) => `R$ ${(val / 1000).toFixed(0)}k`}
              />
              <Tooltip content={<CustomChartTooltip />} />
              <Legend
                wrapperStyle={{ paddingTop: 16, fontSize: 12 }}
                iconType="circle"
              />
              <Line
                type="monotone"
                dataKey="Receitas"
                stroke="#059669"
                strokeWidth={2.5}
                dot={{ r: 4, strokeWidth: 2, fill: '#ffffff', stroke: '#059669' }}
                activeDot={{ r: 6, fill: '#059669' }}
                name="Receitas"
              />
              <Line
                type="monotone"
                dataKey="Despesas"
                stroke="#e11d48"
                strokeWidth={2.5}
                dot={{ r: 4, strokeWidth: 2, fill: '#ffffff', stroke: '#e11d48' }}
                activeDot={{ r: 6, fill: '#e11d48' }}
                name="Despesas Totais"
              />
              <Line
                type="monotone"
                dataKey="Saldo"
                stroke="#2563eb"
                strokeWidth={2.5}
                dot={{ r: 4, strokeWidth: 2, fill: '#ffffff', stroke: '#2563eb' }}
                activeDot={{ r: 6, fill: '#2563eb' }}
                name="Saldo Disponível"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bloco 2: Resumo Consolidado por Grupo (Aba "Total") */}
      <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-xs">
        <div className="px-6 py-4 border-b border-neutral-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h2 className="text-base font-semibold text-neutral-900">
              Aba "Total" — Resumo Geral Consolidado ({MONTH_NAMES[selectedMonth]})
            </h2>
            <p className="text-xs text-neutral-500">
              Confronto direto do orçamento previsto com a saída ou entrada real em cada bloco.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onGoToBudget}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-neutral-700 hover:text-neutral-900 px-3 py-1.5 bg-neutral-100 hover:bg-neutral-200 rounded-md transition-colors cursor-pointer"
            >
              <span>Editar Orçamento</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-neutral-50 text-neutral-600 uppercase text-[11px] tracking-wider border-b border-neutral-200 font-medium">
              <tr>
                <th className="py-3 px-4 sm:px-6">Grupo / Bloco Orçamentário</th>
                <th className="py-3 px-4 text-right">Orçamento Previsto</th>
                <th className="py-3 px-4 text-right">Executado (Real)</th>
                <th className="py-3 px-4 text-right">Diferença</th>
                <th className="py-3 px-4 text-center hidden md:table-cell">% Executado</th>
                <th className="py-3 px-4 sm:px-6 text-right">Diagnóstico</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {summaryRows.map((row, index) => {
                const isOverBudget =
                  row.type === 'expense' && row.actual > row.planned;

                return (
                  <tr key={index} className="hover:bg-neutral-50/70 transition-colors">
                    <td className="py-3.5 px-4 sm:px-6">
                      <div className="font-semibold text-neutral-900">{row.group}</div>
                      <div className="text-[11px] text-neutral-400">{row.description}</div>
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono text-neutral-700">
                      {formatCurrency(row.planned)}
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono font-semibold text-neutral-900">
                      {formatCurrency(row.actual)}
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono font-medium">
                      <span
                        className={
                          row.isFavorable ? 'text-emerald-600' : 'text-rose-600'
                        }
                      >
                        {row.diff > 0 ? '+' : ''}
                        {formatCurrency(row.diff)}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 hidden md:table-cell">
                      <div className="flex items-center justify-center gap-2">
                        <span className="font-mono text-xs text-neutral-600 w-12 text-right">
                          {formatPercent(row.pct)}
                        </span>
                        <div className="w-20 bg-neutral-100 h-1.5 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              row.type === 'income'
                                ? 'bg-emerald-500'
                                : isOverBudget
                                ? 'bg-rose-500'
                                : 'bg-neutral-800'
                            }`}
                            style={{ width: `${Math.min(row.pct, 100)}%` }}
                          />
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 sm:px-6 text-right">
                      {row.type === 'income' ? (
                        row.actual >= row.planned ? (
                          <span className="inline-flex items-center gap-1 text-emerald-700 text-xs font-medium">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Meta batida</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-amber-700 text-xs font-medium">
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                            <span>Abaixo do previsto</span>
                          </span>
                        )
                      ) : isOverBudget ? (
                        <span className="inline-flex items-center gap-1 text-rose-700 text-xs font-medium">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                          <span>Acima do orçado</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-emerald-700 text-xs font-medium">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Dentro da meta</span>
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>

            {/* Linhas de Totalização Consolidada */}
            <tfoot className="bg-neutral-50/90 border-t-2 border-neutral-200 text-xs sm:text-sm font-semibold">
              <tr>
                <td className="py-3.5 px-4 sm:px-6 text-neutral-900">
                  Total de Saídas (Despesas + Economias)
                </td>
                <td className="py-3.5 px-4 text-right font-mono text-neutral-800">
                  {formatCurrency(totalOutflowPlanned)}
                </td>
                <td className="py-3.5 px-4 text-right font-mono text-neutral-900">
                  {formatCurrency(totalOutflowActual)}
                </td>
                <td className="py-3.5 px-4 text-right font-mono text-neutral-700">
                  {formatCurrency(totalOutflowPlanned - totalOutflowActual)}
                </td>
                <td className="py-3.5 px-4 text-center hidden md:table-cell font-mono">
                  {formatPercent(incomeActual > 0 ? (totalOutflowActual / incomeActual) * 100 : 0)}
                </td>
                <td className="py-3.5 px-4 sm:px-6 text-right text-neutral-500 font-normal text-xs">
                  {totalOutflowActual <= incomeActual ? 'Sustentável' : 'Atenção ao déficit'}
                </td>
              </tr>

              <tr className="bg-neutral-100/70 border-t border-neutral-200">
                <td className="py-3.5 px-4 sm:px-6 text-neutral-900 font-bold">
                  Resultado Líquido do Mês (Saldo Final)
                </td>
                <td className="py-3.5 px-4 text-right font-mono text-neutral-600">
                  {formatCurrency(availableBudget)} (Orçado)
                </td>
                <td
                  className={`py-3.5 px-4 text-right font-mono text-base font-bold ${
                    availableToSpend >= 0 ? 'text-emerald-700' : 'text-rose-600'
                  }`}
                >
                  {formatCurrency(availableToSpend)}
                </td>
                <td className="py-3.5 px-4 text-right font-mono text-neutral-700" colSpan={3}>
                  <span className="text-xs text-neutral-500 font-normal">
                    {availableToSpend >= 0
                      ? 'Dinheiro restante após quitar todas as despesas e economias do mês'
                      : 'Alerta: gastos superaram as receitas no período'}
                  </span>
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Bloco 3: Distribuição Visual e Insights Operacionais */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Distribuição do Orçamento */}
        <div className="lg:col-span-2 bg-white border border-neutral-200 rounded-xl p-6 shadow-xs">
          <h3 className="text-sm font-semibold text-neutral-900 mb-1">
            Distribuição Proporcional dos Recursos
          </h3>
          <p className="text-xs text-neutral-500 mb-4">
            Como cada Real recebido ({formatCurrency(incomeActual)}) foi distribuído entre as obrigações:
          </p>

          {/* Barra Empilhada Proporcional */}
          <div className="w-full h-5 rounded-md overflow-hidden flex bg-neutral-100">
            {incomeActual > 0 && (
              <>
                <div
                  style={{ width: `${Math.min((fixedActual / incomeActual) * 100, 100)}%` }}
                  className="bg-neutral-800 hover:opacity-90 transition-opacity"
                  title={`Despesas Fixas: ${formatCurrency(fixedActual)}`}
                />
                <div
                  style={{ width: `${Math.min((variableActual / incomeActual) * 100, 100)}%` }}
                  className="bg-amber-500 hover:opacity-90 transition-opacity"
                  title={`Despesas Variáveis: ${formatCurrency(variableActual)}`}
                />
                <div
                  style={{ width: `${Math.min(((debtActual + debtExtraPaid) / incomeActual) * 100, 100)}%` }}
                  className="bg-rose-500 hover:opacity-90 transition-opacity"
                  title={`Dívidas: ${formatCurrency(debtActual + debtExtraPaid)}`}
                />
                <div
                  style={{ width: `${Math.min((savingsActual / incomeActual) * 100, 100)}%` }}
                  className="bg-emerald-600 hover:opacity-90 transition-opacity"
                  title={`Economias & Investimentos: ${formatCurrency(savingsActual)}`}
                />
              </>
            )}
          </div>

          {/* Legenda limpa sem pílulas artificiais */}
          <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-xs bg-neutral-800 shrink-0" />
              <div>
                <span className="text-neutral-500 block">Fixas</span>
                <span className="font-mono font-medium text-neutral-900">
                  {formatCurrency(fixedActual)}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-xs bg-amber-500 shrink-0" />
              <div>
                <span className="text-neutral-500 block">Variáveis</span>
                <span className="font-mono font-medium text-neutral-900">
                  {formatCurrency(variableActual)}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-xs bg-rose-500 shrink-0" />
              <div>
                <span className="text-neutral-500 block">Dívidas & Extras</span>
                <span className="font-mono font-medium text-neutral-900">
                  {formatCurrency(debtActual + debtExtraPaid)}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-xs bg-emerald-600 shrink-0" />
              <div>
                <span className="text-neutral-500 block">Investimentos</span>
                <span className="font-mono font-medium text-neutral-900">
                  {formatCurrency(savingsActual)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Card de Ações Rápidas & Diagnóstico */}
        <div className="bg-white border border-neutral-200 rounded-xl p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-neutral-900 uppercase tracking-wider mb-2">
              <Zap className="w-4 h-4 text-amber-500" />
              <span>Diagnóstico Orçamentário</span>
            </div>
            <p className="text-xs text-neutral-600 leading-relaxed">
              {availableToSpend > 0 ? (
                <>
                  Você possui um saldo positivo de{' '}
                  <strong className="text-emerald-700 font-mono">
                    {formatCurrency(availableToSpend)}
                  </strong>
                  . Este valor pode ser destinado a amortizar mais parcelas de suas dívidas ou
                  potencializar sua reserva de emergência.
                </>
              ) : (
                <>
                  Atenção: seus gastos ultrapassaram as entradas em{' '}
                  <strong className="text-rose-600 font-mono">
                    {formatCurrency(Math.abs(availableToSpend))}
                  </strong>
                  . Reavalie gastos variáveis para reequilibrar o mês.
                </>
              )}
            </p>
          </div>

          <div className="pt-4 border-t border-neutral-100 flex flex-col gap-2">
            <button
              type="button"
              onClick={onOpenNewTransaction}
              className="w-full text-center py-2 px-3 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded-md transition-colors cursor-pointer"
            >
              Registrar Movimentação Real
            </button>
            <button
              type="button"
              onClick={onGoToTransactions}
              className="w-full text-center py-2 px-3 text-xs font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-md transition-colors cursor-pointer"
            >
              Ver Todas as Transações ({currentMonthBudget.transactions.length})
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
