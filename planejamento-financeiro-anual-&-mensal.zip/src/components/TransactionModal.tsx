import React, { useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { FinanceGroup, MonthIndex, PaymentMethod } from '../types/finance';
import { DEFAULT_CATEGORIES_BY_GROUP } from '../utils/initialData';
import { getTodayISO } from '../utils/formatters';
import { X, ArrowDownRight, ArrowUpRight } from 'lucide-react';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { selectedMonth, year, currentMonthBudget, addTransaction } = useFinance();

  const [date, setDate] = useState<string>(getTodayISO());
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [group, setGroup] = useState<FinanceGroup>('variable');
  const [category, setCategory] = useState<string>('Alimentação');
  const [customCategory, setCustomCategory] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [amount, setAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('pix');
  const [status, setStatus] = useState<'paid' | 'pending'>('paid');
  const [budgetItemId, setBudgetItemId] = useState<string>('');

  if (!isOpen) return null;

  const availableCategories = DEFAULT_CATEGORIES_BY_GROUP[group] || [];
  const groupBudgetItems = currentMonthBudget.items.filter((i) => i.group === group);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount.replace(',', '.'));
    if (!numAmount || numAmount <= 0) {
      alert('Informe um valor válido maior que zero.');
      return;
    }
    if (!description.trim()) {
      alert('Informe a descrição da movimentação.');
      return;
    }

    const finalCategory = customCategory.trim() || category;

    addTransaction({
      date,
      month: selectedMonth,
      year,
      type,
      group,
      category: finalCategory,
      description: description.trim(),
      amount: numAmount,
      paymentMethod,
      status,
      budgetItemId: budgetItemId || undefined,
    });

    onClose();
  };

  const handleGroupChange = (newGroup: FinanceGroup) => {
    setGroup(newGroup);
    const defaultCat = DEFAULT_CATEGORIES_BY_GROUP[newGroup]?.[0] || 'Outros';
    setCategory(defaultCat);
    setBudgetItemId('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full overflow-hidden border border-neutral-200">
        <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {type === 'income' ? (
              <div className="p-1.5 bg-emerald-100 text-emerald-700 rounded-md">
                <ArrowUpRight className="w-4 h-4" />
              </div>
            ) : (
              <div className="p-1.5 bg-rose-100 text-rose-700 rounded-md">
                <ArrowDownRight className="w-4 h-4" />
              </div>
            )}
            <h3 className="text-base font-semibold text-neutral-900">
              Registrar Nova Transação
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-neutral-400 hover:text-neutral-600 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Tipo de Movimento */}
          <div>
            <label className="text-xs font-medium text-neutral-700 block mb-1.5">
              Tipo de Operação
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  setType('expense');
                  setGroup('variable');
                }}
                className={`py-2 px-3 text-xs font-medium rounded-lg border transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
                  type === 'expense'
                    ? 'bg-rose-50 border-rose-300 text-rose-800 font-semibold'
                    : 'bg-white border-neutral-200 text-neutral-600 hover:bg-neutral-50'
                }`}
              >
                <ArrowDownRight className="w-3.5 h-3.5" />
                <span>Despesa / Saída</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setType('income');
                  setGroup('income');
                  setCategory('Trabalho Principal');
                }}
                className={`py-2 px-3 text-xs font-medium rounded-lg border transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
                  type === 'income'
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-800 font-semibold'
                    : 'bg-white border-neutral-200 text-neutral-600 hover:bg-neutral-50'
                }`}
              >
                <ArrowUpRight className="w-3.5 h-3.5" />
                <span>Receita / Entrada</span>
              </button>
            </div>
          </div>

          {/* Grupo Orçamentário */}
          <div>
            <label className="text-xs font-medium text-neutral-700 block mb-1">
              Grupo Orçamentário
            </label>
            <select
              value={group}
              onChange={(e) => handleGroupChange(e.target.value as FinanceGroup)}
              className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
            >
              {type === 'income' ? (
                <option value="income">Receitas & Entradas</option>
              ) : (
                <>
                  <option value="variable">Despesas Variáveis</option>
                  <option value="fixed">Despesas Fixas</option>
                  <option value="debt">Dívidas & Empréstimos</option>
                  <option value="savings">Economias & Investimentos</option>
                </>
              )}
            </select>
          </div>

          {/* Descrição e Valor */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-neutral-700 block mb-1">
                Descrição
              </label>
              <input
                type="text"
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Ex: Supermercado, Aluguel, Salário..."
                className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-neutral-700 block mb-1">
                Valor (R$)
              </label>
              <input
                type="number"
                step="0.01"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0,00"
                className="w-full px-3 py-2 text-xs font-mono font-medium bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Categoria e Data */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-neutral-700 block mb-1">
                Categoria
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
              >
                {availableCategories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
                <option value="custom">+ Nova categoria personalizada</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-medium text-neutral-700 block mb-1">
                Data do Lançamento
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 text-xs font-mono bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          </div>

          {category === 'custom' && (
            <div>
              <label className="text-xs font-medium text-neutral-700 block mb-1">
                Nome da Nova Categoria
              </label>
              <input
                type="text"
                value={customCategory}
                onChange={(e) => setCustomCategory(e.target.value)}
                placeholder="Ex: Cursos Online, Consultoria..."
                className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          )}

          {/* Forma de Pagamento e Status */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-neutral-700 block mb-1">
                Forma de Pagamento
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none cursor-pointer"
              >
                <option value="pix">PIX</option>
                <option value="credit_card">Cartão de Crédito</option>
                <option value="debit_card">Cartão de Débito</option>
                <option value="bank_slip">Boleto Bancário</option>
                <option value="transfer">Transferência Bancária</option>
                <option value="cash">Dinheiro em Espécie</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-medium text-neutral-700 block mb-1">
                Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none cursor-pointer"
              >
                <option value="paid">Efetivado (Pago/Entrou)</option>
                <option value="pending">Pendente (Agendado)</option>
              </select>
            </div>
          </div>

          {/* Vincular a Item do Orçamento Existente */}
          {groupBudgetItems.length > 0 && (
            <div>
              <label className="text-xs font-medium text-neutral-700 block mb-1">
                Vincular a Linha do Orçamento (Opcional)
              </label>
              <select
                value={budgetItemId}
                onChange={(e) => setBudgetItemId(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none cursor-pointer"
              >
                <option value="">Não vincular a nenhum item específico</option>
                {groupBudgetItems.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name} (Orçado: R$ {item.planned.toFixed(2)})
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="pt-3 border-t border-neutral-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-neutral-600 hover:text-neutral-900 cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-md transition-colors cursor-pointer"
            >
              Salvar Transação
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
