import React, { useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import {
  Download,
  Upload,
  Plus,
  RefreshCw,
  FileSpreadsheet,
  Check,
} from 'lucide-react';

interface HeaderProps {
  onOpenNewTransaction: () => void;
  onOpenNewBudgetItem: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenNewTransaction,
  onOpenNewBudgetItem,
}) => {
  const {
    year,
    setYear,
    resetToDefaults,
    exportJSON,
    importJSON,
    exportCSV,
  } = useFinance();

  const [showImportModal, setShowImportModal] = useState(false);
  const [importText, setImportText] = useState('');
  const [importStatus, setImportStatus] = useState<string | null>(null);

  const handleImport = () => {
    if (!importText.trim()) return;
    const ok = importJSON(importText);
    if (ok) {
      setImportStatus('Dados importados com sucesso!');
      setTimeout(() => {
        setShowImportModal(false);
        setImportStatus(null);
        setImportText('');
      }, 1200);
    } else {
      setImportStatus('Erro: Formato JSON inválido.');
    }
  };

  return (
    <>
      <header className="bg-white border-b border-neutral-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Zone 1: Brand single element wordmark */}
            <div className="flex items-center gap-3">
              <a href="/" className="text-lg font-bold tracking-tight text-neutral-900 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
                <span>FinPlan</span>
              </a>
              <span className="text-xs text-neutral-400 hidden sm:inline">Planejamento Orçamentário</span>
            </div>

            {/* Zone 2: Ano e Ferramentas */}
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-neutral-100 rounded-md text-xs font-medium text-neutral-700">
                <span>Ano:</span>
                <select
                  value={year}
                  onChange={(e) => setYear(Number(e.target.value))}
                  aria-label="Selecionar ano"
                  className="bg-transparent font-semibold text-neutral-900 focus:outline-none cursor-pointer"
                >
                  <option value={2025}>2025</option>
                  <option value={2026}>2026</option>
                  <option value={2027}>2027</option>
                </select>
              </div>

              <button
                type="button"
                onClick={exportCSV}
                title="Exportar transações em CSV"
                className="hidden md:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-700 bg-white border border-neutral-200 rounded-md hover:bg-neutral-50 transition-colors whitespace-nowrap cursor-pointer"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                <span>CSV</span>
              </button>

              <button
                type="button"
                onClick={exportJSON}
                title="Backup dos dados em JSON"
                className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-700 bg-white border border-neutral-200 rounded-md hover:bg-neutral-50 transition-colors whitespace-nowrap cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-neutral-500" />
                <span>Backup</span>
              </button>

              <button
                type="button"
                onClick={() => setShowImportModal(true)}
                title="Restaurar backup"
                className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-700 bg-white border border-neutral-200 rounded-md hover:bg-neutral-50 transition-colors whitespace-nowrap cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5 text-neutral-500" />
                <span>Restaurar</span>
              </button>
            </div>

            {/* Zone 3: Ações Primárias */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onOpenNewBudgetItem}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-800 bg-neutral-100 hover:bg-neutral-200 rounded-md transition-colors whitespace-nowrap cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Novo Item Orçado</span>
              </button>

              <button
                type="button"
                onClick={onOpenNewTransaction}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-md shadow-xs transition-colors whitespace-nowrap cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Nova Transação</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Modal de Importação */}
      {showImportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 border border-neutral-200">
            <h3 className="text-base font-semibold text-neutral-900 mb-2">Restaurar Dados (JSON)</h3>
            <p className="text-xs text-neutral-500 mb-4">
              Cole o conteúdo do arquivo JSON de backup exportado anteriormente para recuperar o planejamento.
            </p>
            <textarea
              value={importText}
              onChange={(e) => setImportText(e.target.value)}
              placeholder="Cole o código JSON aqui..."
              className="w-full h-36 p-3 text-xs font-mono bg-neutral-50 border border-neutral-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
            {importStatus && (
              <p
                className={`text-xs mt-2 ${
                  importStatus.includes('sucesso') ? 'text-emerald-600 font-medium' : 'text-rose-600'
                }`}
              >
                {importStatus}
              </p>
            )}
            <div className="flex justify-between items-center mt-5">
              <button
                type="button"
                onClick={() => {
                  if (window.confirm('Tem certeza? Isso restaurará os dados de demonstração padrão para todos os meses.')) {
                    resetToDefaults();
                    setShowImportModal(false);
                  }
                }}
                className="text-xs text-rose-600 hover:text-rose-700 inline-flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Restaurar Padrão</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowImportModal(false)}
                  className="px-3 py-1.5 text-xs text-neutral-600 hover:text-neutral-900 cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleImport}
                  className="px-3.5 py-1.5 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-md cursor-pointer"
                >
                  Confirmar Importação
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
