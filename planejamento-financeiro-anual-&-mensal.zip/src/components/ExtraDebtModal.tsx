import React, { useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { BudgetItem } from '../types/finance';
import { formatCurrency, getTodayISO } from '../utils/formatters';
import { X, Sparkles, TrendingDown } from 'lucide-react';

interface ExtraDebtModalProps {
  item: BudgetItem | null;
  onClose: () => void;
}

export const ExtraDebtModal: React.FC<ExtraDebtModalProps> = ({
  item,
  onClose,
}) => {
  const { updateBudgetItem, addTransaction, selectedMonth, year } = useFinance();

  const [extraAmount, setExtraAmount] = useState<string>(
    item?.extraPayment ? String(item.extraPayment) : ''
  );
  const [createTransaction, setCreateTransaction] = useState(true);

  if (!item) return null;

  const currentExtra = item.extraPayment || 0;
  const currentTotalDebt = item.totalDebt || 0;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(extraAmount.replace(',', '.')) || 0;

    // Atualiza o item de dívida
    const newTotalDebt =
      currentTotalDebt > 0 ? Math.max(0, currentTotalDebt - (amountNum - currentExtra)) : undefined;

    updateBudgetItem({
      ...item,
      extraPayment: amountNum,
      totalDebt: newTotalDebt,
    });

    // Se o usuário optou por criar a transação correspondente
    if (createTransaction && amountNum > currentExtra) {
      const addedAmount = amountNum - currentExtra;
      addTransaction({
        date: getTodayISO(),
        month: selectedMonth,
        year,
        type: 'expense',
        group: 'debt',
        category: item.category,
        description: `Amortização Extra: ${item.name}`,
        amount: addedAmount,
        paymentMethod: 'pix',
        status: 'paid',
        budgetItemId: item.id,
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-md w-full overflow-hidden border border-neutral-200">
        <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-emerald-100 text-emerald-700 rounded-md">
              <Sparkles className="w-4 h-4" />
            </div>
            <h3 className="text-base font-semibold text-neutral-900">
              Pagamento Extra / Amortização
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-neutral-400 hover:text-neutral-600 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSave} className="p-6 space-y-4">
          <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-200 space-y-1">
            <span className="text-xs text-neutral-500 block">Dívida Selecionada:</span>
            <div className="text-sm font-semibold text-neutral-900">{item.name}</div>
            <div className="flex items-center justify-between text-xs text-neutral-600 pt-1">
              <span>Parcela Regular: {formatCurrency(item.planned)}</span>
              {currentTotalDebt > 0 && (
                <span>Saldo Devedor: {formatCurrency(currentTotalDebt)}</span>
              )}
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-neutral-700 block mb-1">
              Valor do Pagamento Extra para este Mês (R$)
            </label>
            <input
              type="number"
              step="0.01"
              required
              value={extraAmount}
              onChange={(e) => setExtraAmount(e.target.value)}
              placeholder="Ex: 500,00"
              className="w-full px-3 py-2 text-sm font-mono font-semibold bg-white border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
            <p className="text-[11px] text-neutral-500 mt-1">
              Este valor será somado como saída no mês para acelerar a liquidação da dívida.
            </p>
          </div>

          <label className="flex items-center gap-2 cursor-pointer text-xs text-neutral-700 pt-1">
            <input
              type="checkbox"
              checked={createTransaction}
              onChange={(e) => setCreateTransaction(e.target.checked)}
              className="rounded border-neutral-300 text-emerald-600 focus:ring-emerald-500"
            />
            <span>Gerar transação de saída automaticamente no extrato</span>
          </label>

          <div className="pt-3 border-t border-neutral-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-neutral-600 hover:text-neutral-900 cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-md transition-colors cursor-pointer"
            >
              Confirmar Pagamento Extra
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
