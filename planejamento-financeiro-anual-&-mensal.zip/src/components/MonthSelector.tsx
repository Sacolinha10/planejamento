import React from 'react';
import { useFinance } from '../context/FinanceContext';
import { MonthIndex, MONTH_NAMES, MONTH_SHORT_NAMES } from '../types/finance';
import { ChevronLeft, ChevronRight, Copy } from 'lucide-react';
import { formatCurrency } from '../utils/formatters';

interface MonthSelectorProps {
  onOpenCopyModal: () => void;
}

export const MonthSelector: React.FC<MonthSelectorProps> = ({ onOpenCopyModal }) => {
  const { selectedMonth, setSelectedMonth, allMonthsSummaries, year } = useFinance();

  const handlePrev = () => {
    if (selectedMonth > 0) {
      setSelectedMonth((selectedMonth - 1) as MonthIndex);
    } else {
      setSelectedMonth(11 as MonthIndex);
    }
  };

  const handleNext = () => {
    if (selectedMonth < 11) {
      setSelectedMonth((selectedMonth + 1) as MonthIndex);
    } else {
      setSelectedMonth(0 as MonthIndex);
    }
  };

  return (
    <div className="bg-white border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="py-2.5 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          {/* Navegação e Nome do Mês Ativo */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handlePrev}
                title="Mês anterior"
                className="p-1.5 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-md transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <div className="min-w-36 text-center">
                <span className="text-sm font-bold text-neutral-900">
                  {MONTH_NAMES[selectedMonth]} {year}
                </span>
              </div>
              <button
                type="button"
                onClick={handleNext}
                title="Próximo mês"
                className="p-1.5 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-md transition-colors cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <button
              type="button"
              onClick={onOpenCopyModal}
              title="Copiar estrutura de orçamento de outro mês"
              className="text-xs text-neutral-600 hover:text-neutral-900 inline-flex items-center gap-1 px-2.5 py-1 bg-neutral-100 hover:bg-neutral-200 rounded-md transition-colors cursor-pointer"
            >
              <Copy className="w-3 h-3" />
              <span>Copiar Orçamento</span>
            </button>
          </div>

          {/* Barra de 12 Meses (Jan a Dez) */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
            {([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] as MonthIndex[]).map((m) => {
              const isSelected = selectedMonth === m;
              const summary = allMonthsSummaries[m];
              const balance = summary ? summary.availableToSpend : 0;
              const isPositive = balance >= 0;

              return (
                <button
                  key={m}
                  type="button"
                  onClick={() => setSelectedMonth(m)}
                  className={`px-2.5 py-1 text-xs rounded-md transition-all flex flex-col items-center shrink-0 cursor-pointer ${
                    isSelected
                      ? 'bg-neutral-900 text-white font-semibold shadow-xs'
                      : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
                  }`}
                >
                  <span className="leading-tight">{MONTH_SHORT_NAMES[m]}</span>
                  <span
                    className={`text-[10px] font-mono leading-tight ${
                      isSelected
                        ? isPositive
                          ? 'text-emerald-300'
                          : 'text-rose-300'
                        : isPositive
                        ? 'text-emerald-600'
                        : 'text-rose-600'
                    }`}
                  >
                    {isPositive ? '+' : ''}{Math.round(balance / 1000)}k
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
