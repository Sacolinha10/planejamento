import React, { useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { MONTH_NAMES, MONTH_SHORT_NAMES, MonthIndex } from '../types/finance';
import { formatCurrency, formatPercent } from '../utils/formatters';
import {
  TrendingUp,
  TrendingDown,
  Scale,
  PieChart,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle2,
  AlertTriangle,
  Sliders,
  Sparkles,
} from 'lucide-react';

export const IncomeExpensesView: React.FC = () => {
  const {
    currentSummary,
    selectedMonth,
    setSelectedMonth,
    allMonthsSummaries,
    year,
    currentMonthBudget,
  } = useFinance();

  const [scope, setScope] = useState<'month' | 'year'>('month');
  
  // Simulador interativo
  const [extraIncomeSim, setExtraIncomeSim] = useState<number>(0);
  const [expenseCutPercentSim, setExpenseCutPercentSim] = useState<number>(0);

  // Dados do mês
  const {
    incomeActual,
    incomePlanned,
    fixedActual,
    variableActual,
    debtActual,
    debtExtraPaid,
    savingsActual,
  } = currentSummary;

  const totalExpensesActual = fixedActual + variableActual + debtActual + debtExtraPaid;
  const netIncomeMonth = incomeActual - totalExpensesActual;

  // Totais do ano
  const annualTotals = allMonthsSummaries.reduce(
    (acc, m) => {
      acc.income += m.incomeActual;
      acc.fixed += m.fixedActual;
      acc.variable += m.variableActual;
      acc.debt += m.debtActual + m.debtExtraPaid;
      acc.savings += m.savingsActual;
      acc.expenses += m.fixedActual + m.variableActual + m.debtActual + m.debtExtraPaid;
      return acc;
    },
    { income: 0, fixed: 0, variable: 0, debt: 0, savings: 0, expenses: 0 }
  );

  const activeIncome = scope === 'month' ? incomeActual : annualTotals.income;
  const activeExpenses = scope === 'month' ? totalExpensesActual : annualTotals.expenses;
  const activeNet = activeIncome - activeExpenses;
  const activeSavings = scope === 'month' ? savingsActual : annualTotals.savings;

  // Cobertura de despesas (receita / despesas)
  const coverageRatio = activeExpenses > 0 ? (activeIncome / activeExpenses) : 1;

  // Categorização de Despesas para Ranking (do mês)
  const categoryExpensesMap: Record<string, { planned: number; actual: number; group: string }> = {};

  currentMonthBudget.items
    .filter((i) => i.group === 'fixed' || i.group === 'variable' || i.group === 'debt')
    .forEach((item) => {
      const cat = item.category || 'Outros';
      const actualVal = item.actual + (item.extraPayment || 0);
      if (!categoryExpensesMap[cat]) {
        categoryExpensesMap[cat] = { planned: 0, actual: 0, group: item.group };
      }
      categoryExpensesMap[cat].planned += item.planned;
      categoryExpensesMap[cat].actual += actualVal;
    });

  const categoryRank = Object.entries(categoryExpensesMap)
    .map(([category, data]) => ({
      category,
      ...data,
      diff: data.planned - data.actual, // Positivo = economia
      percentOfTotal: totalExpensesActual > 0 ? (data.actual / totalExpensesActual) * 100 : 0,
    }))
    .sort((a, b) => b.actual - a.actual);

  // Fontes de Receita do Mês
  const incomeItems = currentMonthBudget.items.filter((i) => i.group === 'income');

  // Regra 50-30-20
  const needsRatio = activeIncome > 0 ? (currentSummary.fixedActual / activeIncome) * 100 : 0;
  const wantsRatio = activeIncome > 0 ? (currentSummary.variableActual / activeIncome) * 100 : 0;
  const savingsDebtRatio =
    activeIncome > 0
      ? ((currentSummary.savingsActual + currentSummary.debtActual + currentSummary.debtExtraPaid) /
          activeIncome) *
        100
      : 0;

  // Efeito da simulação
  const simulatedExpenseCut = (currentSummary.variableActual * expenseCutPercentSim) / 100;
  const simulatedNewExpenses = totalExpensesActual - simulatedExpenseCut;
  const simulatedNewIncome = incomeActual + extraIncomeSim;
  const simulatedNewBalance = simulatedNewIncome - simulatedNewExpenses;
  const simulatedGain = simulatedNewBalance - netIncomeMonth;

  // Escala para o gráfico de Jan a Dez
  const maxVal = Math.max(
    ...allMonthsSummaries.map((s) =>
      Math.max(s.incomeActual, s.fixedActual + s.variableActual + s.debtActual + s.debtExtraPaid)
    ),
    1000
  );

  return (
    <div className="space-y-6">
      {/* Barra de Controle de Escopo */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-white p-4 rounded-xl border border-neutral-200 shadow-xs">
        <div>
          <h2 className="text-base font-bold text-neutral-900 flex items-center gap-2">
            <Scale className="w-5 h-5 text-neutral-700" />
            <span>Raio-X de Receitas & Despesas</span>
          </h2>
          <p className="text-xs text-neutral-500">
            Confronto direto entre entradas e saídas, centros de custo e índice de sustentabilidade.
          </p>
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-neutral-100 rounded-lg self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setScope('month')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all cursor-pointer ${
              scope === 'month'
                ? 'bg-white text-neutral-900 shadow-xs font-semibold'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            Mês: {MONTH_NAMES[selectedMonth]}
          </button>
          <button
            type="button"
            onClick={() => setScope('year')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all cursor-pointer ${
              scope === 'year'
                ? 'bg-white text-neutral-900 shadow-xs font-semibold'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            Acumulado Anual ({year})
          </button>
        </div>
      </div>

      {/* Cards de Comparação Principal */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Receitas Totais */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-emerald-800">
              Receitas Realizadas
            </span>
            <div className="p-1.5 bg-emerald-50 text-emerald-600 rounded-md">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono tracking-tight text-neutral-900">
            {formatCurrency(activeIncome)}
          </div>
          <div className="mt-2 text-xs text-neutral-500 flex items-center justify-between">
            <span>{scope === 'month' ? 'Previsto no mês:' : 'Previsão anual:'}</span>
            <span className="font-mono text-neutral-700">
              {formatCurrency(scope === 'month' ? incomePlanned : annualTotals.income)}
            </span>
          </div>
        </div>

        {/* Despesas Totais */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-rose-800">
              Despesas Realizadas
            </span>
            <div className="p-1.5 bg-rose-50 text-rose-600 rounded-md">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono tracking-tight text-neutral-900">
            {formatCurrency(activeExpenses)}
          </div>
          <div className="mt-2 text-xs text-neutral-500 flex items-center justify-between">
            <span>Fixas + Variáveis + Dívidas</span>
            <span className="font-mono text-rose-600 font-medium">
              {formatPercent(activeIncome > 0 ? (activeExpenses / activeIncome) * 100 : 0)} da renda
            </span>
          </div>
        </div>

        {/* Saldo Operacional Líquido */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-neutral-500">
              Saldo Líquido (Receita - Despesas)
            </span>
            <div className="p-1.5 bg-neutral-100 text-neutral-700 rounded-md">
              <Scale className="w-4 h-4" />
            </div>
          </div>
          <div
            className={`text-2xl font-bold font-mono tracking-tight ${
              activeNet >= 0 ? 'text-emerald-700' : 'text-rose-600'
            }`}
          >
            {formatCurrency(activeNet)}
          </div>
          <div className="mt-2 text-xs text-neutral-500 flex items-center justify-between">
            <span>Status do Período:</span>
            <span
              className={`font-semibold ${
                activeNet >= 0 ? 'text-emerald-700' : 'text-rose-600'
              }`}
            >
              {activeNet >= 0 ? 'Superávit Caixa' : 'Déficit no Período'}
            </span>
          </div>
        </div>

        {/* Cobertura e Sustentabilidade */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-neutral-500">
              Índice de Cobertura
            </span>
            <div className="p-1.5 bg-blue-50 text-blue-600 rounded-md">
              <PieChart className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono tracking-tight text-neutral-900">
            {coverageRatio.toFixed(2)}x
          </div>
          <div className="mt-2 text-xs text-neutral-500">
            {coverageRatio >= 1 ? (
              <span className="text-emerald-700 flex items-center gap-1 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Receita cobre 100% dos custos</span>
              </span>
            ) : (
              <span className="text-rose-600 flex items-center gap-1 font-medium">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Gastos superam entradas</span>
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Gráfico Comparativo Mensal de Jan a Dez (Receitas vs Despesas) */}
      <div className="bg-white border border-neutral-200 rounded-xl p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-6">
          <div>
            <h3 className="text-base font-bold text-neutral-900">
              Comparativo Mensal de Receitas vs Despesas ({year})
            </h3>
            <p className="text-xs text-neutral-500">
              Evolução das entradas (verde) versus saídas totais (cinza) mês a mês. Clique em um mês para detalhar.
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 bg-emerald-600 rounded-xs" />
              <span className="text-neutral-700">Receitas</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 bg-neutral-800 rounded-xs" />
              <span className="text-neutral-700">Despesas Totais</span>
            </div>
          </div>
        </div>

        {/* Barras SVG / CSS Responsivas */}
        <div className="grid grid-cols-12 gap-1.5 sm:gap-3 items-end h-56 pt-6 pb-2 border-b border-neutral-200">
          {([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] as MonthIndex[]).map((m) => {
            const sm = allMonthsSummaries[m];
            const inc = sm.incomeActual;
            const exp = sm.fixedActual + sm.variableActual + sm.debtActual + sm.debtExtraPaid;
            const isSelected = selectedMonth === m;

            const incHeightPct = maxVal > 0 ? Math.min((inc / maxVal) * 100, 100) : 0;
            const expHeightPct = maxVal > 0 ? Math.min((exp / maxVal) * 100, 100) : 0;

            const isSurplus = inc >= exp;

            return (
              <button
                key={m}
                type="button"
                onClick={() => setSelectedMonth(m)}
                title={`${MONTH_NAMES[m]}: Receita ${formatCurrency(inc)} | Despesas ${formatCurrency(exp)}`}
                className={`flex flex-col items-center justify-end h-full group cursor-pointer transition-all p-1 rounded-lg ${
                  isSelected ? 'bg-neutral-100 ring-1 ring-neutral-300' : 'hover:bg-neutral-50'
                }`}
              >
                <div className="flex items-end gap-1 w-full justify-center h-44">
                  {/* Barra de Receita */}
                  <div
                    style={{ height: `${incHeightPct}%` }}
                    className="w-2.5 sm:w-4 bg-emerald-600 group-hover:bg-emerald-500 rounded-t-xs transition-all"
                  />
                  {/* Barra de Despesas */}
                  <div
                    style={{ height: `${expHeightPct}%` }}
                    className="w-2.5 sm:w-4 bg-neutral-800 group-hover:bg-neutral-700 rounded-t-xs transition-all"
                  />
                </div>

                <div className="mt-2 text-center">
                  <span
                    className={`block text-[10px] sm:text-xs font-semibold ${
                      isSelected ? 'text-neutral-900' : 'text-neutral-600'
                    }`}
                  >
                    {MONTH_SHORT_NAMES[m]}
                  </span>
                  <span
                    className={`block text-[9px] font-mono leading-none ${
                      isSurplus ? 'text-emerald-700' : 'text-rose-600'
                    }`}
                  >
                    {isSurplus ? '▲' : '▼'}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Dois Blocos: Fontes de Receita vs Centros de Custos de Despesas */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bloco 1: Fontes de Receitas */}
        <div className="bg-white border border-neutral-200 rounded-xl p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
              <h3 className="text-sm font-bold text-neutral-900 flex items-center gap-1.5">
                <ArrowUpRight className="w-4 h-4 text-emerald-600" />
                <span>Fontes de Receita ({MONTH_NAMES[selectedMonth]})</span>
              </h3>
              <span className="font-mono text-xs font-semibold text-emerald-700">
                Total: {formatCurrency(incomeActual)}
              </span>
            </div>

            <div className="divide-y divide-neutral-100 mt-2">
              {incomeItems.length === 0 ? (
                <p className="py-4 text-xs text-neutral-400 text-center">
                  Nenhuma fonte de receita cadastrada neste mês.
                </p>
              ) : (
                incomeItems.map((item) => {
                  const share = incomeActual > 0 ? (item.actual / incomeActual) * 100 : 0;
                  const diff = item.actual - item.planned;

                  return (
                    <div key={item.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                      <div>
                        <div className="font-semibold text-neutral-900">{item.name}</div>
                        <div className="text-[11px] text-neutral-400">
                          {item.category} · Previsto: {formatCurrency(item.planned)}
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="font-mono font-bold text-neutral-900">
                          {formatCurrency(item.actual)}
                        </div>
                        <div className="text-[11px] flex items-center justify-end gap-1.5">
                          <span className="text-neutral-500 font-mono">{formatPercent(share)}</span>
                          <span className="text-neutral-300">·</span>
                          <span
                            className={`font-mono font-medium ${
                              diff >= 0 ? 'text-emerald-600' : 'text-rose-600'
                            }`}
                          >
                            {diff >= 0 ? '+' : ''}
                            {formatCurrency(diff)}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-neutral-100 text-xs text-neutral-500">
            Dica: Manter mais de uma fonte de receita reduz significativamente a vulnerabilidade financeira.
          </div>
        </div>

        {/* Bloco 2: Ranking dos Maiores Centros de Custos de Despesas */}
        <div className="bg-white border border-neutral-200 rounded-xl p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
              <h3 className="text-sm font-bold text-neutral-900 flex items-center gap-1.5">
                <ArrowDownRight className="w-4 h-4 text-rose-600" />
                <span>Maiores Centros de Custo ({MONTH_NAMES[selectedMonth]})</span>
              </h3>
              <span className="font-mono text-xs font-semibold text-neutral-900">
                Total: {formatCurrency(totalExpensesActual)}
              </span>
            </div>

            <div className="space-y-3 mt-3">
              {categoryRank.slice(0, 6).map((cat, idx) => (
                <div key={cat.category} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-neutral-800">
                      {idx + 1}. {cat.category}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-semibold text-neutral-900">
                        {formatCurrency(cat.actual)}
                      </span>
                      <span className="font-mono text-neutral-500 text-[11px]">
                        ({formatPercent(cat.percentOfTotal)})
                      </span>
                    </div>
                  </div>

                  <div className="w-full bg-neutral-100 h-1.5 rounded-full overflow-hidden">
                    <div
                      style={{ width: `${Math.min(cat.percentOfTotal, 100)}%` }}
                      className="bg-neutral-800 h-full rounded-full"
                    />
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-neutral-400">
                    <span>Orçado: {formatCurrency(cat.planned)}</span>
                    <span
                      className={`font-mono font-medium ${
                        cat.diff >= 0 ? 'text-emerald-600' : 'text-rose-600'
                      }`}
                    >
                      {cat.diff >= 0 ? 'Economizou ' : 'Estourou '}
                      {formatCurrency(Math.abs(cat.diff))}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-neutral-100 text-xs text-neutral-500">
            As três maiores categorias concentram a maior parte do seu orçamento de saídas.
          </div>
        </div>
      </div>

      {/* Bloco 3: Diagnóstico da Regra 50-30-20 & Simulador Interativo */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Diagnóstico 50-30-20 */}
        <div className="bg-white border border-neutral-200 rounded-xl p-6 shadow-xs">
          <h3 className="text-sm font-bold text-neutral-900 mb-1">
            Equilíbrio Estrutural (Método 50 / 30 / 20)
          </h3>
          <p className="text-xs text-neutral-500 mb-4">
            Comparação da sua divisão atual versus a referência de saúde orçamentária:
          </p>

          <div className="space-y-4">
            {/* 50% Necessidades Básicas */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-medium text-neutral-800">
                  Necessidades Fixas (Meta: até 50%)
                </span>
                <span className="font-mono font-bold text-neutral-900">
                  {formatPercent(needsRatio)} ({formatCurrency(currentSummary.fixedActual)})
                </span>
              </div>
              <div className="w-full bg-neutral-100 h-2 rounded-full overflow-hidden">
                <div
                  style={{ width: `${Math.min(needsRatio, 100)}%` }}
                  className={`h-full rounded-full ${
                    needsRatio <= 50 ? 'bg-emerald-600' : 'bg-amber-500'
                  }`}
                />
              </div>
            </div>

            {/* 30% Despesas Variáveis / Estilo de Vida */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-medium text-neutral-800">
                  Despesas Variáveis (Meta: até 30%)
                </span>
                <span className="font-mono font-bold text-neutral-900">
                  {formatPercent(wantsRatio)} ({formatCurrency(currentSummary.variableActual)})
                </span>
              </div>
              <div className="w-full bg-neutral-100 h-2 rounded-full overflow-hidden">
                <div
                  style={{ width: `${Math.min(wantsRatio, 100)}%` }}
                  className={`h-full rounded-full ${
                    wantsRatio <= 30 ? 'bg-emerald-600' : 'bg-amber-500'
                  }`}
                />
              </div>
            </div>

            {/* 20% Dívidas & Poupança / Investimentos */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-medium text-neutral-800">
                  Poupança, Metas & Amortizações (Meta: 20%+)
                </span>
                <span className="font-mono font-bold text-neutral-900">
                  {formatPercent(savingsDebtRatio)} (
                  {formatCurrency(
                    currentSummary.savingsActual +
                      currentSummary.debtActual +
                      currentSummary.debtExtraPaid
                  )}
                  )
                </span>
              </div>
              <div className="w-full bg-neutral-100 h-2 rounded-full overflow-hidden">
                <div
                  style={{ width: `${Math.min(savingsDebtRatio, 100)}%` }}
                  className={`h-full rounded-full ${
                    savingsDebtRatio >= 20 ? 'bg-emerald-600' : 'bg-rose-500'
                  }`}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Simulador de Cenários Rápidos */}
        <div className="bg-white border border-neutral-200 rounded-xl p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Sliders className="w-4 h-4 text-emerald-600" />
              <h3 className="text-sm font-bold text-neutral-900">
                Simulador de Ajuste de Receitas e Despesas
              </h3>
            </div>
            <p className="text-xs text-neutral-500 mb-4">
              Simule o impacto de gerar renda extra ou reduzir custos variáveis no seu saldo do mês:
            </p>

            <div className="space-y-4 text-xs">
              <div>
                <div className="flex justify-between text-neutral-700 mb-1">
                  <span>Adicionar Renda Extra:</span>
                  <span className="font-mono font-bold text-emerald-700">
                    +{formatCurrency(extraIncomeSim)}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="3000"
                  step="100"
                  value={extraIncomeSim}
                  onChange={(e) => setExtraIncomeSim(Number(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-neutral-700 mb-1">
                  <span>Redução de Gastos Variáveis:</span>
                  <span className="font-mono font-bold text-emerald-700">
                    -{expenseCutPercentSim}% ({formatCurrency(simulatedExpenseCut)})
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="50"
                  step="5"
                  value={expenseCutPercentSim}
                  onChange={(e) => setExpenseCutPercentSim(Number(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
              </div>

              <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-200 space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-neutral-600 font-medium">Novo Saldo Livre Simulado:</span>
                  <span className="font-mono text-sm font-bold text-emerald-700">
                    {formatCurrency(simulatedNewBalance)}
                  </span>
                </div>
                {simulatedGain > 0 && (
                  <div className="text-[11px] text-emerald-600 flex items-center gap-1 font-medium">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>
                      Você ganha {formatCurrency(simulatedGain)} a mais por mês para amortizar ou poupar!
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center justify-between">
            <button
              type="button"
              onClick={() => {
                setExtraIncomeSim(0);
                setExpenseCutPercentSim(0);
              }}
              className="text-xs text-neutral-500 hover:text-neutral-800 cursor-pointer"
            >
              Resetar Simulação
            </button>
            <span className="text-[11px] text-neutral-400">Tempo real</span>
          </div>
        </div>
      </div>
    </div>
  );
};
