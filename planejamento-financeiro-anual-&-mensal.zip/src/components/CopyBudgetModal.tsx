import React, { useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { MonthIndex, MONTH_NAMES } from '../types/finance';
import { X, Copy } from 'lucide-react';

interface CopyBudgetModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CopyBudgetModal: React.FC<CopyBudgetModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { selectedMonth, copyBudgetFromMonth } = useFinance();

  const [sourceMonth, setSourceMonth] = useState<MonthIndex>(() => {
    return selectedMonth > 0 ? ((selectedMonth - 1) as MonthIndex) : 0;
  });

  if (!isOpen) return null;

  const handleCopy = () => {
    if (sourceMonth === selectedMonth) {
      alert('Selecione um mês de origem diferente do mês de destino.');
      return;
    }
    if (
      window.confirm(
        `Deseja copiar o orçamento planejado de ${MONTH_NAMES[sourceMonth]} para ${MONTH_NAMES[selectedMonth]}?`
      )
    ) {
      copyBudgetFromMonth(sourceMonth, selectedMonth);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-md w-full overflow-hidden border border-neutral-200">
        <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Copy className="w-4 h-4 text-neutral-700" />
            <h3 className="text-base font-semibold text-neutral-900">
              Copiar Estrutura de Orçamento
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-neutral-400 hover:text-neutral-600 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <p className="text-xs text-neutral-600">
            Replique todas as categorias, despesas e valores planejados de outro mês para{' '}
            <strong className="text-neutral-900 font-semibold">{MONTH_NAMES[selectedMonth]}</strong>.
            Os valores realizados começarão zerados para que você registre os gastos deste novo mês.
          </p>

          <div>
            <label className="text-xs font-medium text-neutral-700 block mb-1">
              Copiar do Mês de Origem:
            </label>
            <select
              value={sourceMonth}
              onChange={(e) => setSourceMonth(Number(e.target.value) as MonthIndex)}
              className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none cursor-pointer"
            >
              {([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] as MonthIndex[]).map((m) => (
                <option key={m} value={m}>
                  {MONTH_NAMES[m]}
                </option>
              ))}
            </select>
          </div>

          <div className="pt-3 border-t border-neutral-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-neutral-600 hover:text-neutral-900 cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={handleCopy}
              className="px-4 py-2 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded-md transition-colors cursor-pointer"
            >
              Copiar para {MONTH_NAMES[selectedMonth]}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
