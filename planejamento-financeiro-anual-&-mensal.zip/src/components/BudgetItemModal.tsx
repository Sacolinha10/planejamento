import React, { useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { FinanceGroup } from '../types/finance';
import { DEFAULT_CATEGORIES_BY_GROUP } from '../utils/initialData';
import { X } from 'lucide-react';

interface BudgetItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultGroup?: FinanceGroup;
}

export const BudgetItemModal: React.FC<BudgetItemModalProps> = ({
  isOpen,
  onClose,
  defaultGroup = 'variable',
}) => {
  const { addBudgetItem } = useFinance();

  const [name, setName] = useState('');
  const [group, setGroup] = useState<FinanceGroup>(defaultGroup);
  const [category, setCategory] = useState<string>('Alimentação');
  const [customCategory, setCustomCategory] = useState<string>('');
  const [planned, setPlanned] = useState<string>('');
  const [actual, setActual] = useState<string>('');
  const [totalDebt, setTotalDebt] = useState<string>('');
  const [extraPayment, setExtraPayment] = useState<string>('');
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const categories = DEFAULT_CATEGORIES_BY_GROUP[group] || [];

  const handleGroupChange = (newGroup: FinanceGroup) => {
    setGroup(newGroup);
    const firstCat = DEFAULT_CATEGORIES_BY_GROUP[newGroup]?.[0] || 'Geral';
    setCategory(firstCat);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Informe o nome do item no orçamento.');
      return;
    }

    const finalCat = customCategory.trim() || category;
    const numPlanned = parseFloat(planned.replace(',', '.')) || 0;
    const numActual = parseFloat(actual.replace(',', '.')) || 0;
    const numDebt = totalDebt ? parseFloat(totalDebt.replace(',', '.')) : undefined;
    const numExtra = extraPayment ? parseFloat(extraPayment.replace(',', '.')) : 0;

    addBudgetItem({
      name: name.trim(),
      category: finalCat,
      group,
      planned: numPlanned,
      actual: numActual,
      totalDebt: numDebt,
      extraPayment: numExtra,
      notes: notes.trim() || undefined,
      isCustom: true,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full overflow-hidden border border-neutral-200">
        <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between">
          <h3 className="text-base font-semibold text-neutral-900">
            Adicionar Linha ao Orçamento
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="text-neutral-400 hover:text-neutral-600 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Grupo */}
          <div>
            <label className="text-xs font-medium text-neutral-700 block mb-1">
              Bloco Orçamentário
            </label>
            <select
              value={group}
              onChange={(e) => handleGroupChange(e.target.value as FinanceGroup)}
              className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
            >
              <option value="income">Receitas & Entradas</option>
              <option value="fixed">Despesas Fixas</option>
              <option value="variable">Despesas Variáveis</option>
              <option value="debt">Dívidas & Empréstimos</option>
              <option value="savings">Economias & Investimentos</option>
            </select>
          </div>

          {/* Nome do Item */}
          <div>
            <label className="text-xs font-medium text-neutral-700 block mb-1">
              Nome do Item
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Celular, Combustível, Amortização Carro, Reserva..."
              className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          {/* Categoria */}
          <div>
            <label className="text-xs font-medium text-neutral-700 block mb-1">
              Categoria
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none cursor-pointer"
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
              <option value="custom">+ Adicionar Categoria Personalizada</option>
            </select>
          </div>

          {category === 'custom' && (
            <div>
              <label className="text-xs font-medium text-neutral-700 block mb-1">
                Nome da Categoria Personalizada
              </label>
              <input
                type="text"
                value={customCategory}
                onChange={(e) => setCustomCategory(e.target.value)}
                placeholder="Ex: Assinatura IA, Gastos Pet, Academia..."
                className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          )}

          {/* Valores Orçado e Realizado */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-neutral-700 block mb-1">
                Valor Previsto / Orçado (R$)
              </label>
              <input
                type="number"
                step="0.01"
                required
                value={planned}
                onChange={(e) => setPlanned(e.target.value)}
                placeholder="0,00"
                className="w-full px-3 py-2 text-xs font-mono bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-neutral-700 block mb-1">
                Saída / Entrada Real Inicial (R$)
              </label>
              <input
                type="number"
                step="0.01"
                value={actual}
                onChange={(e) => setActual(e.target.value)}
                placeholder="0,00 (opcional)"
                className="w-full px-3 py-2 text-xs font-mono bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Campos específicos de Dívidas */}
          {group === 'debt' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-neutral-50 rounded-lg border border-neutral-200">
              <div>
                <label className="text-xs font-medium text-neutral-700 block mb-1">
                  Saldo Devedor Total (R$)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={totalDebt}
                  onChange={(e) => setTotalDebt(e.target.value)}
                  placeholder="Ex: 15000,00"
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-neutral-200 rounded-md focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-emerald-800 block mb-1">
                  Pagamento Extra / Amortização
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={extraPayment}
                  onChange={(e) => setExtraPayment(e.target.value)}
                  placeholder="Ex: 300,00"
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-emerald-300 rounded-md focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* Observações */}
          <div>
            <label className="text-xs font-medium text-neutral-700 block mb-1">
              Notas / Observações (Opcional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ex: Vencimento dia 10, Parcela 3/12..."
              className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none"
            />
          </div>

          <div className="pt-3 border-t border-neutral-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-neutral-600 hover:text-neutral-900 cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded-md transition-colors cursor-pointer"
            >
              Adicionar ao Orçamento
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
