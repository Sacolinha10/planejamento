import React from 'react';
import { useFinance } from '../context/FinanceContext';
import { MonthIndex, MONTH_NAMES } from '../types/finance';
import { formatCurrency, formatPercent } from '../utils/formatters';
import {
  CalendarDays,
  ArrowRight,
  TrendingUp,
  Wallet,
  PiggyBank,
  CreditCard,
  CheckCircle2,
} from 'lucide-react';

interface AnnualViewProps {
  onSelectMonth: (month: MonthIndex) => void;
}

export const AnnualView: React.FC<AnnualViewProps> = ({ onSelectMonth }) => {
  const { allMonthsSummaries, year, selectedMonth } = useFinance();

  // Cálculos consolidados do ano todo (soma de Jan a Dez)
  const annualTotals = allMonthsSummaries.reduce(
    (acc, m) => {
      acc.incomePlanned += m.incomePlanned;
      acc.incomeActual += m.incomeActual;
      acc.fixedActual += m.fixedActual;
      acc.variableActual += m.variableActual;
      acc.debtActual += m.debtActual + m.debtExtraPaid;
      acc.savingsActual += m.savingsActual;
      acc.totalOutflowActual += m.totalOutflowActual;
      acc.availableToSpend += m.availableToSpend;
      acc.budgetRemainingToSpend += m.budgetRemainingToSpend;
      return acc;
    },
    {
      incomePlanned: 0,
      incomeActual: 0,
      fixedActual: 0,
      variableActual: 0,
      debtActual: 0,
      savingsActual: 0,
      totalOutflowActual: 0,
      availableToSpend: 0,
      budgetRemainingToSpend: 0,
    }
  );

  const annualSavingsRate =
    annualTotals.incomeActual > 0
      ? (annualTotals.savingsActual / annualTotals.incomeActual) * 100
      : 0;

  return (
    <div className="space-y-6">
      {/* Cards de Resumo Anual (Consolidado Jan - Dez) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Receita Anual */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-neutral-500">
              Receitas Totais ({year})
            </span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold font-mono tracking-tight text-neutral-900">
            {formatCurrency(annualTotals.incomeActual)}
          </div>
          <p className="text-xs text-neutral-500 mt-2">
            Total efetivo que entrou no seu caixa durante os 12 meses.
          </p>
        </div>

        {/* Total Deixado para Gastar (Disponível Líquido) */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-neutral-500">
              Total Restante no Ano
            </span>
            <Wallet className="w-4 h-4 text-blue-600" />
          </div>
          <div
            className={`text-2xl font-bold font-mono tracking-tight ${
              annualTotals.availableToSpend >= 0 ? 'text-neutral-900' : 'text-rose-600'
            }`}
          >
            {formatCurrency(annualTotals.availableToSpend)}
          </div>
          <p className="text-xs text-neutral-500 mt-2">
            Saldo acumulado livre após quitar todas as despesas e investimentos.
          </p>
        </div>

        {/* Total Economizado & Investido */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-neutral-500">
              Investido no Ano
            </span>
            <PiggyBank className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold font-mono tracking-tight text-emerald-700">
            {formatCurrency(annualTotals.savingsActual)}
          </div>
          <p className="text-xs text-neutral-500 mt-2">
            Taxa média de poupança:{' '}
            <strong className="font-mono text-neutral-800">{formatPercent(annualSavingsRate)}</strong>
          </p>
        </div>

        {/* Total Pago de Dívidas */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-neutral-500">
              Dívidas Quitadas ({year})
            </span>
            <CreditCard className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-2xl font-bold font-mono tracking-tight text-neutral-900">
            {formatCurrency(annualTotals.debtActual)}
          </div>
          <p className="text-xs text-neutral-500 mt-2">
            Soma de parcelas regulares e amortizações extraordinárias.
          </p>
        </div>
      </div>

      {/* Matriz Mensal: Janeiro a Dezembro */}
      <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-xs">
        <div className="px-6 py-4 border-b border-neutral-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h3 className="text-base font-semibold text-neutral-900">
              Panorama Mensal Consolidado (Janeiro a Dezembro de {year})
            </h3>
            <p className="text-xs text-neutral-500">
              Acompanhamento mês a mês de quanto restou para gastar e da evolução de cada grupo de despesas.
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-neutral-50 text-neutral-500 uppercase text-[10px] sm:text-[11px] tracking-wider border-b border-neutral-200">
              <tr>
                <th className="py-3 px-4 sm:px-6">Mês</th>
                <th className="py-3 px-3 text-right">Receitas Reais</th>
                <th className="py-3 px-3 text-right">Despesas Fixas</th>
                <th className="py-3 px-3 text-right">Despesas Variáveis</th>
                <th className="py-3 px-3 text-right">Dívidas & Extras</th>
                <th className="py-3 px-3 text-right">Economias</th>
                <th className="py-3 px-3 text-right bg-neutral-100/40">Restou p/ Gastar</th>
                <th className="py-3 px-3 text-right font-semibold">Saldo Livre</th>
                <th className="py-3 px-4 sm:px-6 text-center w-28">Navegar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] as MonthIndex[]).map((m) => {
                const s = allMonthsSummaries[m];
                const isCurrent = selectedMonth === m;

                return (
                  <tr
                    key={m}
                    className={`hover:bg-neutral-50/80 transition-colors ${
                      isCurrent ? 'bg-neutral-50 font-medium' : ''
                    }`}
                  >
                    <td className="py-3 px-4 sm:px-6 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        {isCurrent && (
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                        )}
                        <span className="font-semibold text-neutral-900">
                          {MONTH_NAMES[m]}
                        </span>
                      </div>
                    </td>

                    <td className="py-3 px-3 text-right font-mono text-emerald-700">
                      {formatCurrency(s.incomeActual)}
                    </td>

                    <td className="py-3 px-3 text-right font-mono text-neutral-700">
                      {formatCurrency(s.fixedActual)}
                    </td>

                    <td className="py-3 px-3 text-right font-mono text-neutral-700">
                      {formatCurrency(s.variableActual)}
                    </td>

                    <td className="py-3 px-3 text-right font-mono text-rose-600">
                      {formatCurrency(s.debtActual + s.debtExtraPaid)}
                    </td>

                    <td className="py-3 px-3 text-right font-mono text-emerald-600">
                      {formatCurrency(s.savingsActual)}
                    </td>

                    {/* Quanto deixei para gastar (Margem do Orçamento) */}
                    <td className="py-3 px-3 text-right font-mono bg-neutral-100/40">
                      <span
                        className={
                          s.budgetRemainingToSpend >= 0
                            ? 'text-indigo-600 font-medium'
                            : 'text-rose-600 font-medium'
                        }
                      >
                        {formatCurrency(s.budgetRemainingToSpend)}
                      </span>
                    </td>

                    {/* Saldo Real em Conta (Disponível para Gastar) */}
                    <td className="py-3 px-3 text-right font-mono font-semibold">
                      <span
                        className={
                          s.availableToSpend >= 0 ? 'text-emerald-700' : 'text-rose-600'
                        }
                      >
                        {formatCurrency(s.availableToSpend)}
                      </span>
                    </td>

                    <td className="py-3 px-4 sm:px-6 text-center">
                      <button
                        type="button"
                        onClick={() => onSelectMonth(m)}
                        className={`px-2.5 py-1 text-xs rounded-md transition-colors cursor-pointer inline-flex items-center gap-1 ${
                          isCurrent
                            ? 'bg-neutral-900 text-white font-medium'
                            : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-200 bg-neutral-100'
                        }`}
                      >
                        <span>Ver Mês</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>

            {/* Totalizador Anual */}
            <tfoot className="bg-neutral-100/80 border-t-2 border-neutral-200 text-xs sm:text-sm font-bold">
              <tr>
                <td className="py-3.5 px-4 sm:px-6 text-neutral-900">
                  TOTAL ANUAL ({year})
                </td>
                <td className="py-3.5 px-3 text-right font-mono text-emerald-800">
                  {formatCurrency(annualTotals.incomeActual)}
                </td>
                <td className="py-3.5 px-3 text-right font-mono text-neutral-900">
                  {formatCurrency(annualTotals.fixedActual)}
                </td>
                <td className="py-3.5 px-3 text-right font-mono text-neutral-900">
                  {formatCurrency(annualTotals.variableActual)}
                </td>
                <td className="py-3.5 px-3 text-right font-mono text-rose-700">
                  {formatCurrency(annualTotals.debtActual)}
                </td>
                <td className="py-3.5 px-3 text-right font-mono text-emerald-700">
                  {formatCurrency(annualTotals.savingsActual)}
                </td>
                <td className="py-3.5 px-3 text-right font-mono text-indigo-700 bg-neutral-200/50">
                  {formatCurrency(annualTotals.budgetRemainingToSpend)}
                </td>
                <td
                  className={`py-3.5 px-3 text-right font-mono text-base ${
                    annualTotals.availableToSpend >= 0 ? 'text-emerald-800' : 'text-rose-700'
                  }`}
                >
                  {formatCurrency(annualTotals.availableToSpend)}
                </td>
                <td className="py-3.5 px-4 sm:px-6 text-center text-neutral-400 font-normal text-xs">
                  12 Meses
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
};
