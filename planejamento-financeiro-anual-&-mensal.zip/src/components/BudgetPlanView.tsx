import React, { useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { BudgetItem, FinanceGroup, MONTH_NAMES } from '../types/finance';
import { formatCurrency } from '../utils/formatters';
import {
  TrendingUp,
  Home,
  ShoppingBag,
  CreditCard,
  PiggyBank,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  Sparkles,
} from 'lucide-react';

interface BudgetPlanViewProps {
  onOpenNewItem: (group?: FinanceGroup) => void;
  onOpenExtraDebtModal: (item: BudgetItem) => void;
}

export const BudgetPlanView: React.FC<BudgetPlanViewProps> = ({
  onOpenNewItem,
  onOpenExtraDebtModal,
}) => {
  const {
    currentMonthBudget,
    selectedMonth,
    updateBudgetItem,
    deleteBudgetItem,
    currentSummary,
  } = useFinance();

  // Edição rápida de valores em linha
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValues, setEditValues] = useState<{
    name: string;
    planned: number;
    actual: number;
    extraPayment?: number;
    totalDebt?: number;
    category: string;
  }>({
    name: '',
    planned: 0,
    actual: 0,
    category: '',
  });

  const startEditing = (item: BudgetItem) => {
    setEditingId(item.id);
    setEditValues({
      name: item.name,
      planned: item.planned,
      actual: item.actual,
      extraPayment: item.extraPayment,
      totalDebt: item.totalDebt,
      category: item.category,
    });
  };

  const cancelEditing = () => {
    setEditingId(null);
  };

  const saveEditing = (originalItem: BudgetItem) => {
    updateBudgetItem({
      ...originalItem,
      name: editValues.name.trim() || originalItem.name,
      planned: Number(editValues.planned) || 0,
      actual: Number(editValues.actual) || 0,
      extraPayment: editValues.extraPayment !== undefined ? Number(editValues.extraPayment) : originalItem.extraPayment,
      totalDebt: editValues.totalDebt !== undefined ? Number(editValues.totalDebt) : originalItem.totalDebt,
      category: editValues.category || originalItem.category,
    });
    setEditingId(null);
  };

  // Filtragem dos itens por bloco
  const incomeItems = currentMonthBudget.items.filter((i) => i.group === 'income');
  const fixedItems = currentMonthBudget.items.filter((i) => i.group === 'fixed');
  const variableItems = currentMonthBudget.items.filter((i) => i.group === 'variable');
  const debtItems = currentMonthBudget.items.filter((i) => i.group === 'debt');
  const savingsItems = currentMonthBudget.items.filter((i) => i.group === 'savings');

  const renderSection = (
    title: string,
    subtitle: string,
    group: FinanceGroup,
    items: BudgetItem[],
    icon: React.ReactNode,
    totalPlanned: number,
    totalActual: number,
    extraPaidTotal = 0
  ) => {
    const isIncome = group === 'income';
    const isDebt = group === 'debt';
    const diff = isIncome
      ? totalActual - totalPlanned
      : totalPlanned - (totalActual + extraPaidTotal);

    return (
      <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-xs">
        {/* Cabeçalho do Bloco */}
        <div className="p-4 sm:px-6 sm:py-4 border-b border-neutral-200 flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-neutral-50/50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white border border-neutral-200 rounded-lg text-neutral-700 shadow-2xs">
              {icon}
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-neutral-900">{title}</h3>
              <p className="text-xs text-neutral-500">{subtitle}</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="text-right text-xs">
              <span className="text-neutral-500 mr-1.5">Total Previsto:</span>
              <strong className="font-mono text-neutral-800">{formatCurrency(totalPlanned)}</strong>
              <span className="mx-2 text-neutral-300">|</span>
              <span className="text-neutral-500 mr-1.5">Real:</span>
              <strong className="font-mono text-neutral-900">
                {formatCurrency(totalActual + extraPaidTotal)}
              </strong>
              <span className="mx-2 text-neutral-300">|</span>
              <span className="text-neutral-500 mr-1.5">Dif:</span>
              <strong
                className={`font-mono ${
                  diff >= 0 ? 'text-emerald-600' : 'text-rose-600'
                }`}
              >
                {diff > 0 ? '+' : ''}
                {formatCurrency(diff)}
              </strong>
            </div>

            <button
              type="button"
              onClick={() => onOpenNewItem(group)}
              className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-neutral-900 bg-white border border-neutral-200 rounded-md hover:bg-neutral-100 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-neutral-600" />
              <span>Adicionar Linha</span>
            </button>
          </div>
        </div>

        {/* Tabela de Itens */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-neutral-50 text-neutral-500 uppercase text-[10px] sm:text-[11px] tracking-wider border-b border-neutral-200">
              <tr>
                <th className="py-2.5 px-4 sm:px-6">Descrição</th>
                <th className="py-2.5 px-3">Categoria</th>
                <th className="py-2.5 px-3 text-right">
                  {isIncome ? 'Valor Previsto' : 'Valor Orçado'}
                </th>
                <th className="py-2.5 px-3 text-right">
                  {isIncome ? 'Entrou (Real)' : 'Saída Real'}
                </th>
                {isDebt && (
                  <>
                    <th className="py-2.5 px-3 text-right text-emerald-700">Amortização Extra</th>
                    <th className="py-2.5 px-3 text-right text-neutral-600">Saldo Devedor</th>
                  </>
                )}
                <th className="py-2.5 px-3 text-right">Diferença</th>
                <th className="py-2.5 px-4 sm:px-6 text-right w-24">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {items.length === 0 ? (
                <tr>
                  <td
                    colSpan={isDebt ? 8 : 6}
                    className="py-6 px-4 text-center text-xs text-neutral-400"
                  >
                    Nenhum item cadastrado neste bloco. Clique em "+ Adicionar Linha".
                  </td>
                </tr>
              ) : (
                items.map((item) => {
                  const isEditing = editingId === item.id;
                  const itemExtra = item.extraPayment || 0;
                  const itemDiff = isIncome
                    ? item.actual - item.planned
                    : item.planned - (item.actual + itemExtra);

                  if (isEditing) {
                    return (
                      <tr key={item.id} className="bg-emerald-50/40">
                        <td className="py-2.5 px-4 sm:px-6">
                          <input
                            type="text"
                            value={editValues.name}
                            onChange={(e) =>
                              setEditValues({ ...editValues, name: e.target.value })
                            }
                            className="w-full px-2 py-1 text-xs bg-white border border-neutral-300 rounded focus:outline-none focus:ring-1 focus:ring-emerald-500"
                            placeholder="Nome do item"
                          />
                        </td>
                        <td className="py-2.5 px-3">
                          <input
                            type="text"
                            value={editValues.category}
                            onChange={(e) =>
                              setEditValues({ ...editValues, category: e.target.value })
                            }
                            className="w-full px-2 py-1 text-xs bg-white border border-neutral-300 rounded focus:outline-none focus:ring-1 focus:ring-emerald-500"
                            placeholder="Categoria"
                          />
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <input
                            type="number"
                            step="0.01"
                            value={editValues.planned}
                            onChange={(e) =>
                              setEditValues({
                                ...editValues,
                                planned: parseFloat(e.target.value) || 0,
                              })
                            }
                            className="w-24 text-right px-2 py-1 text-xs font-mono bg-white border border-neutral-300 rounded focus:outline-none focus:ring-1 focus:ring-emerald-500"
                          />
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <input
                            type="number"
                            step="0.01"
                            value={editValues.actual}
                            onChange={(e) =>
                              setEditValues({
                                ...editValues,
                                actual: parseFloat(e.target.value) || 0,
                              })
                            }
                            className="w-24 text-right px-2 py-1 text-xs font-mono bg-white border border-neutral-300 rounded focus:outline-none focus:ring-1 focus:ring-emerald-500"
                          />
                        </td>

                        {isDebt && (
                          <>
                            <td className="py-2.5 px-3 text-right">
                              <input
                                type="number"
                                step="0.01"
                                value={editValues.extraPayment || 0}
                                onChange={(e) =>
                                  setEditValues({
                                    ...editValues,
                                    extraPayment: parseFloat(e.target.value) || 0,
                                  })
                                }
                                className="w-24 text-right px-2 py-1 text-xs font-mono bg-white border border-emerald-300 rounded focus:outline-none focus:ring-1 focus:ring-emerald-500 text-emerald-700 font-medium"
                              />
                            </td>
                            <td className="py-2.5 px-3 text-right">
                              <input
                                type="number"
                                step="0.01"
                                value={editValues.totalDebt || 0}
                                onChange={(e) =>
                                  setEditValues({
                                    ...editValues,
                                    totalDebt: parseFloat(e.target.value) || 0,
                                  })
                                }
                                className="w-24 text-right px-2 py-1 text-xs font-mono bg-white border border-neutral-300 rounded focus:outline-none"
                              />
                            </td>
                          </>
                        )}

                        <td className="py-2.5 px-3 text-right font-mono text-xs text-neutral-400">
                          —
                        </td>

                        <td className="py-2.5 px-4 sm:px-6 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => saveEditing(item)}
                              title="Salvar"
                              className="p-1 text-emerald-700 hover:bg-emerald-100 rounded cursor-pointer"
                            >
                              <Check className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={cancelEditing}
                              title="Cancelar"
                              className="p-1 text-neutral-500 hover:bg-neutral-100 rounded cursor-pointer"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  }

                  return (
                    <tr key={item.id} className="hover:bg-neutral-50/70 transition-colors">
                      <td className="py-3 px-4 sm:px-6">
                        <div className="font-medium text-neutral-900">{item.name}</div>
                        {item.notes && (
                          <div className="text-[11px] text-neutral-400">{item.notes}</div>
                        )}
                      </td>

                      <td className="py-3 px-3">
                        <span className="text-xs text-neutral-600">{item.category}</span>
                      </td>

                      <td className="py-3 px-3 text-right font-mono text-neutral-700">
                        {formatCurrency(item.planned)}
                      </td>

                      <td className="py-3 px-3 text-right font-mono font-semibold text-neutral-900">
                        {formatCurrency(item.actual)}
                      </td>

                      {isDebt && (
                        <>
                          <td className="py-3 px-3 text-right font-mono font-semibold text-emerald-700">
                            {itemExtra > 0 ? (
                              formatCurrency(itemExtra)
                            ) : (
                              <button
                                type="button"
                                onClick={() => onOpenExtraDebtModal(item)}
                                className="text-xs text-emerald-600 hover:underline cursor-pointer"
                              >
                                + Amortizar
                              </button>
                            )}
                          </td>
                          <td className="py-3 px-3 text-right font-mono text-neutral-500">
                            {item.totalDebt !== undefined
                              ? formatCurrency(item.totalDebt)
                              : '—'}
                          </td>
                        </>
                      )}

                      <td className="py-3 px-3 text-right font-mono">
                        <span
                          className={
                            itemDiff >= 0 ? 'text-emerald-600 font-medium' : 'text-rose-600 font-medium'
                          }
                        >
                          {itemDiff > 0 ? '+' : ''}
                          {formatCurrency(itemDiff)}
                        </span>
                      </td>

                      <td className="py-3 px-4 sm:px-6 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5 opacity-80 hover:opacity-100">
                          {isDebt && (
                            <button
                              type="button"
                              onClick={() => onOpenExtraDebtModal(item)}
                              title="Registrar Pagamento Extra de Dívida"
                              className="p-1 text-emerald-600 hover:bg-emerald-50 rounded cursor-pointer"
                            >
                              <Sparkles className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => startEditing(item)}
                            title="Editar linha"
                            className="p-1 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded cursor-pointer"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              if (window.confirm(`Excluir "${item.name}" deste mês?`)) {
                                deleteBudgetItem(item.id);
                              }
                            }}
                            title="Remover linha"
                            className="p-1 text-neutral-400 hover:text-rose-600 hover:bg-rose-50 rounded cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Barra de Resumo Rápido da Disponibilidade no topo do Orçamento */}
      <div className="bg-neutral-900 text-white rounded-xl p-4 sm:p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <span className="text-xs text-neutral-400 uppercase tracking-wider block">
            Equilíbrio Orçamentário ({MONTH_NAMES[selectedMonth]})
          </span>
          <div className="text-lg sm:text-xl font-bold font-mono mt-0.5">
            Orçamento Disponível:{' '}
            <span
              className={
                currentSummary.availableBudget >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }
            >
              {formatCurrency(currentSummary.availableBudget)}
            </span>
          </div>
          <p className="text-xs text-neutral-300 mt-1">
            Receitas Previstas ({formatCurrency(currentSummary.incomePlanned)}) − Total Orçado (
            {formatCurrency(currentSummary.totalOutflowPlanned)}).
          </p>
        </div>

        <div className="flex items-center gap-4 border-t md:border-t-0 md:border-l border-neutral-700 pt-3 md:pt-0 md:pl-6 text-xs">
          <div>
            <span className="text-neutral-400 block">Orçado p/ Gastar:</span>
            <span className="font-mono font-semibold text-white">
              {formatCurrency(
                currentSummary.fixedPlanned + currentSummary.variablePlanned
              )}
            </span>
          </div>
          <div>
            <span className="text-neutral-400 block">Gasto Real Atual:</span>
            <span className="font-mono font-semibold text-white">
              {formatCurrency(
                currentSummary.fixedActual + currentSummary.variableActual
              )}
            </span>
          </div>
          <div>
            <span className="text-neutral-400 block">Margem Livre Restante:</span>
            <span
              className={`font-mono font-bold ${
                currentSummary.budgetRemainingToSpend >= 0
                  ? 'text-emerald-400'
                  : 'text-rose-400'
              }`}
            >
              {formatCurrency(currentSummary.budgetRemainingToSpend)}
            </span>
          </div>
        </div>
      </div>

      {/* 1. Receitas */}
      {renderSection(
        '1. Receitas & Entradas',
        'Valores previstos e valores que efetivamente entraram no mês (ex: Salário, Freelance, Dividendos)',
        'income',
        incomeItems,
        <TrendingUp className="w-5 h-5 text-emerald-600" />,
        currentSummary.incomePlanned,
        currentSummary.incomeActual
      )}

      {/* 2. Despesas Fixas */}
      {renderSection(
        '2. Despesas Fixas',
        'Contas recorrentes mensais essenciais (Aluguel, Luz, Celular, Internet, Plano de Saúde)',
        'fixed',
        fixedItems,
        <Home className="w-5 h-5 text-neutral-700" />,
        currentSummary.fixedPlanned,
        currentSummary.fixedActual
      )}

      {/* 3. Despesas Variáveis */}
      {renderSection(
        '3. Despesas Variáveis',
        'Gastos do dia a dia (Supermercado, Restaurante, Combustível, Compras, Farmácia e categorias personalizadas)',
        'variable',
        variableItems,
        <ShoppingBag className="w-5 h-5 text-amber-600" />,
        currentSummary.variablePlanned,
        currentSummary.variableActual
      )}

      {/* 4. Dívidas & Empréstimos */}
      {renderSection(
        '4. Dívidas & Empréstimos',
        'Controle de passivos devidos, parcelamentos e amortizações extras',
        'debt',
        debtItems,
        <CreditCard className="w-5 h-5 text-rose-600" />,
        currentSummary.debtPlanned,
        currentSummary.debtActual,
        currentSummary.debtExtraPaid
      )}

      {/* 5. Economias & Investimentos */}
      {renderSection(
        '5. Economias & Investimentos',
        'Aporte Planejado vs Real para Reserva de Emergência, Ações, Renda Fixa e Metas',
        'savings',
        savingsItems,
        <PiggyBank className="w-5 h-5 text-emerald-600" />,
        currentSummary.savingsPlanned,
        currentSummary.savingsActual
      )}
    </div>
  );
};
