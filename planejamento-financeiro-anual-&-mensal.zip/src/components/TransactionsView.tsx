import React, { useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { FinanceGroup, MONTH_NAMES, PaymentMethod, Transaction } from '../types/finance';
import { formatDateBR, formatCurrency } from '../utils/formatters';
import {
  Search,
  Plus,
  Trash2,
  CheckCircle2,
  Clock,
  ArrowDownRight,
  ArrowUpRight,
  Filter,
} from 'lucide-react';

interface TransactionsViewProps {
  onOpenNewTransaction: () => void;
}

const PAYMENT_LABELS: Record<PaymentMethod, string> = {
  pix: 'PIX',
  credit_card: 'Cartão de Crédito',
  debit_card: 'Cartão de Débito',
  bank_slip: 'Boleto Bancário',
  transfer: 'Transferência / TED',
  cash: 'Dinheiro em Espécie',
};

const GROUP_LABELS: Record<FinanceGroup, string> = {
  income: 'Receitas',
  fixed: 'Despesas Fixas',
  variable: 'Despesas Variáveis',
  debt: 'Dívidas & Empréstimos',
  savings: 'Economias & Invest.',
};

export const TransactionsView: React.FC<TransactionsViewProps> = ({
  onOpenNewTransaction,
}) => {
  const {
    currentMonthBudget,
    selectedMonth,
    deleteTransaction,
    updateTransaction,
  } = useFinance();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [filterGroup, setFilterGroup] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'paid' | 'pending'>('all');

  const transactions = currentMonthBudget.transactions;

  // Filtragem dos lançamentos
  const filteredTransactions = transactions.filter((tx) => {
    // Tipo
    if (filterType !== 'all' && tx.type !== filterType) return false;
    // Grupo
    if (filterGroup !== 'all' && tx.group !== filterGroup) return false;
    // Status
    if (filterStatus !== 'all' && tx.status !== filterStatus) return false;
    // Busca
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const matchDesc = tx.description.toLowerCase().includes(q);
      const matchCat = tx.category.toLowerCase().includes(q);
      const matchVal = tx.amount.toString().includes(q);
      if (!matchDesc && !matchCat && !matchVal) return false;
    }
    return true;
  });

  // Totais rápidos da listagem
  const totalIncomes = transactions
    .filter((t) => t.type === 'income' && t.status === 'paid')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpenses = transactions
    .filter((t) => t.type === 'expense' && t.status === 'paid')
    .reduce((sum, t) => sum + t.amount, 0);

  const netBalance = totalIncomes - totalExpenses;

  const toggleStatus = (tx: Transaction) => {
    updateTransaction({
      ...tx,
      status: tx.status === 'paid' ? 'pending' : 'paid',
    });
  };

  return (
    <div className="space-y-6">
      {/* Resumo de Movimentações */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-neutral-200 rounded-xl p-4 shadow-xs">
          <span className="text-xs text-neutral-500 font-medium uppercase tracking-wider block">
            Entradas Efetivadas
          </span>
          <div className="text-xl font-bold font-mono text-emerald-600 mt-1 flex items-center gap-1.5">
            <ArrowUpRight className="w-5 h-5" />
            <span>{formatCurrency(totalIncomes)}</span>
          </div>
        </div>

        <div className="bg-white border border-neutral-200 rounded-xl p-4 shadow-xs">
          <span className="text-xs text-neutral-500 font-medium uppercase tracking-wider block">
            Saídas Efetivadas
          </span>
          <div className="text-xl font-bold font-mono text-neutral-900 mt-1 flex items-center gap-1.5">
            <ArrowDownRight className="w-5 h-5 text-rose-500" />
            <span>{formatCurrency(totalExpenses)}</span>
          </div>
        </div>

        <div className="bg-white border border-neutral-200 rounded-xl p-4 shadow-xs">
          <span className="text-xs text-neutral-500 font-medium uppercase tracking-wider block">
            Saldo Real em Lançamentos
          </span>
          <div
            className={`text-xl font-bold font-mono mt-1 ${
              netBalance >= 0 ? 'text-emerald-700' : 'text-rose-600'
            }`}
          >
            {formatCurrency(netBalance)}
          </div>
        </div>
      </div>

      {/* Caixa de Tabela & Filtros */}
      <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-xs">
        {/* Barra de Filtros e Busca */}
        <div className="p-4 sm:p-5 border-b border-neutral-200 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h3 className="text-base font-semibold text-neutral-900">
                Histórico de Transações ({MONTH_NAMES[selectedMonth]})
              </h3>
              <p className="text-xs text-neutral-500">
                Extrato detalhado de receitas e despesas registradas no período.
              </p>
            </div>

            <button
              type="button"
              onClick={onOpenNewTransaction}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-md transition-colors cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Nova Transação</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 pt-2">
            {/* Campo de Busca */}
            <div className="relative">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar por descrição, valor..."
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            {/* Filtro por Tipo */}
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as any)}
              aria-label="Filtrar por tipo"
              className="px-3 py-1.5 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
            >
              <option value="all">Todos os Tipos</option>
              <option value="income">Apenas Entradas (Receitas)</option>
              <option value="expense">Apenas Saídas (Despesas)</option>
            </select>

            {/* Filtro por Grupo */}
            <select
              value={filterGroup}
              onChange={(e) => setFilterGroup(e.target.value)}
              aria-label="Filtrar por grupo orçamentário"
              className="px-3 py-1.5 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
            >
              <option value="all">Todos os Grupos</option>
              <option value="income">Receitas</option>
              <option value="fixed">Despesas Fixas</option>
              <option value="variable">Despesas Variáveis</option>
              <option value="debt">Dívidas & Empréstimos</option>
              <option value="savings">Economias & Investimentos</option>
            </select>

            {/* Filtro por Status */}
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              aria-label="Filtrar por status"
              className="px-3 py-1.5 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
            >
              <option value="all">Todos os Status</option>
              <option value="paid">Efetivado (Pago/Recebido)</option>
              <option value="pending">Pendente (Agendado)</option>
            </select>
          </div>
        </div>

        {/* Tabela de Transações */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-neutral-50 text-neutral-500 uppercase text-[10px] sm:text-[11px] tracking-wider border-b border-neutral-200">
              <tr>
                <th className="py-2.5 px-4 sm:px-6">Data</th>
                <th className="py-2.5 px-3">Tipo / Grupo</th>
                <th className="py-2.5 px-4">Descrição</th>
                <th className="py-2.5 px-3">Categoria</th>
                <th className="py-2.5 px-3 hidden md:table-cell">Pagamento</th>
                <th className="py-2.5 px-3 text-right">Valor</th>
                <th className="py-2.5 px-3 text-center">Status</th>
                <th className="py-2.5 px-4 sm:px-6 text-right w-16">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {filteredTransactions.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 px-4 text-center text-neutral-400">
                    <p className="text-sm font-medium text-neutral-700">Nenhuma transação encontrada</p>
                    <p className="text-xs text-neutral-500 mt-1">
                      {transactions.length === 0
                        ? 'Registre sua primeira movimentação no botão acima.'
                        : 'Ajuste os filtros ou termo de busca para encontrar movimentações.'}
                    </p>
                  </td>
                </tr>
              ) : (
                filteredTransactions.map((tx) => {
                  const isIncome = tx.type === 'income';

                  return (
                    <tr key={tx.id} className="hover:bg-neutral-50/70 transition-colors">
                      {/* Data */}
                      <td className="py-3 px-4 sm:px-6 font-mono text-neutral-600 whitespace-nowrap">
                        {formatDateBR(tx.date)}
                      </td>

                      {/* Tipo e Grupo */}
                      <td className="py-3 px-3 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          {isIncome ? (
                            <span className="w-2 h-2 rounded-full bg-emerald-500" />
                          ) : (
                            <span className="w-2 h-2 rounded-full bg-rose-500" />
                          )}
                          <span className="font-medium text-neutral-800">
                            {isIncome ? 'Entrada' : 'Saída'}
                          </span>
                        </div>
                        <span className="text-[11px] text-neutral-400 block">
                          {GROUP_LABELS[tx.group] || tx.group}
                        </span>
                      </td>

                      {/* Descrição */}
                      <td className="py-3 px-4 font-medium text-neutral-900">
                        {tx.description}
                      </td>

                      {/* Categoria */}
                      <td className="py-3 px-3 text-neutral-600">
                        <span className="text-xs">{tx.category}</span>
                      </td>

                      {/* Forma de Pagamento */}
                      <td className="py-3 px-3 hidden md:table-cell text-neutral-500 text-xs">
                        {PAYMENT_LABELS[tx.paymentMethod] || tx.paymentMethod}
                      </td>

                      {/* Valor */}
                      <td className="py-3 px-3 text-right font-mono font-semibold whitespace-nowrap">
                        <span className={isIncome ? 'text-emerald-600' : 'text-neutral-900'}>
                          {isIncome ? '+ ' : '- '}
                          {formatCurrency(tx.amount)}
                        </span>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => toggleStatus(tx)}
                          title="Clique para alternar status"
                          className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded cursor-pointer transition-colors"
                        >
                          {tx.status === 'paid' ? (
                            <span className="text-emerald-700 flex items-center gap-1 font-medium">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              <span>Efetivado</span>
                            </span>
                          ) : (
                            <span className="text-amber-700 flex items-center gap-1 font-medium">
                              <Clock className="w-3.5 h-3.5 text-amber-600" />
                              <span>Pendente</span>
                            </span>
                          )}
                        </button>
                      </td>

                      {/* Ação */}
                      <td className="py-3 px-4 sm:px-6 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => {
                            if (window.confirm(`Excluir o lançamento "${tx.description}"?`)) {
                              deleteTransaction(tx.id);
                            }
                          }}
                          title="Excluir lançamento"
                          className="p-1 text-neutral-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
