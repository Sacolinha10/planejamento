import { BudgetItem, MonthIndex, MonthlyBudget, Transaction } from '../types/finance';

export const DEFAULT_BUDGET_TEMPLATE: Omit<BudgetItem, 'id'>[] = [
  // 1. Receitas
  { name: 'Salário Líquido', category: 'Trabalho Principal', group: 'income', planned: 6500, actual: 6500 },
  { name: 'Renda Extra / Freelance', category: 'Serviços', group: 'income', planned: 900, actual: 950 },
  { name: 'Rendimentos & Dividendos', category: 'Investimentos', group: 'income', planned: 150, actual: 165 },

  // 2. Despesas Fixas
  { name: 'Aluguel & Condomínio', category: 'Moradia', group: 'fixed', planned: 1850, actual: 1850 },
  { name: 'Conta de Energia (Luz)', category: 'Utilidades', group: 'fixed', planned: 220, actual: 215 },
  { name: 'Conta de Celular', category: 'Telecom', group: 'fixed', planned: 79.9, actual: 79.9 },
  { name: 'Internet Fibra', category: 'Telecom', group: 'fixed', planned: 119.9, actual: 119.9 },
  { name: 'Água & Saneamento', category: 'Utilidades', group: 'fixed', planned: 85, actual: 82 },
  { name: 'Plano de Saúde', category: 'Saúde', group: 'fixed', planned: 380, actual: 380 },
  { name: 'Assinaturas de Streaming', category: 'Lazer', group: 'fixed', planned: 95, actual: 95 },

  // 3. Despesas Variáveis
  { name: 'Supermercado & Feira', category: 'Alimentação', group: 'variable', planned: 1200, actual: 1140 },
  { name: 'Restaurante & Delivery', category: 'Alimentação', group: 'variable', planned: 450, actual: 480 },
  { name: 'Combustível / Transporte', category: 'Transporte', group: 'variable', planned: 380, actual: 360 },
  { name: 'Compras Pessoais & Roupas', category: 'Compras', group: 'variable', planned: 250, actual: 190 },
  { name: 'Farmácia & Cuidados', category: 'Saúde', group: 'variable', planned: 160, actual: 125 },
  { name: 'Lazer & Passeios', category: 'Lazer', group: 'variable', planned: 200, actual: 210 },
  { name: 'Outros Imprevistos', category: 'Outros', group: 'variable', planned: 200, actual: 90 },

  // 4. Dívidas & Empréstimos
  {
    name: 'Financiamento do Carro',
    category: 'Veículos',
    group: 'debt',
    planned: 650,
    actual: 650,
    extraPayment: 250,
    totalDebt: 12500,
    notes: 'Parcela 14/36 com amortização extra',
  },
  {
    name: 'Cartão Parcelado (Notebook)',
    category: 'Cartão de Crédito',
    group: 'debt',
    planned: 320,
    actual: 320,
    extraPayment: 0,
    totalDebt: 640,
    notes: 'Parcela 4/6',
  },

  // 5. Economias & Investimentos
  { name: 'Reserva de Emergência', category: 'Reserva', group: 'savings', planned: 500, actual: 500 },
  { name: 'Tesouro Selic / Renda Fixa', category: 'Investimentos', group: 'savings', planned: 400, actual: 400 },
  { name: 'Meta Viagem Fim de Ano', category: 'Metas', group: 'savings', planned: 300, actual: 300 },
];

export const generateInitialYearData = (year: number): MonthlyBudget[] => {
  const months: MonthlyBudget[] = [];

  for (let m = 0; m < 12; m++) {
    const monthIndex = m as MonthIndex;
    
    // Pequenas variações realistas mês a mês para demonstrar o fluxo real
    const items: BudgetItem[] = DEFAULT_BUDGET_TEMPLATE.map((tpl, idx) => {
      let planned = tpl.planned;
      let actual = tpl.actual;
      let extra = tpl.extraPayment || 0;

      // 13º salário em Nov e Dez
      if (tpl.name === 'Salário Líquido' && (m === 10 || m === 11)) {
        planned += 3250;
        actual += 3250;
      }

      // Variações de contas sazonais
      if (tpl.name === 'Conta de Energia (Luz)' && (m === 0 || m === 1)) {
        // Verão / Ar condicionado
        planned = 260;
        actual = 255;
      }
      if (tpl.name === 'Supermercado & Feira') {
        const factor = 1 + ((m % 4) - 2) * 0.04;
        planned = Math.round(tpl.planned * factor);
        actual = Math.round(tpl.actual * factor);
      }
      if (tpl.name === 'Combustível / Transporte') {
        actual = Math.round(tpl.actual + ((m % 3) * 20 - 20));
      }

      // Amortização extra de dívida mais forte em meses com bônus
      if (tpl.group === 'debt' && tpl.name.includes('Financiamento') && (m === 5 || m === 11)) {
        extra = 600;
      }

      return {
        id: `m${m}-item-${idx}`,
        name: tpl.name,
        category: tpl.category,
        group: tpl.group,
        planned,
        actual,
        extraPayment: extra,
        totalDebt: tpl.totalDebt,
        notes: tpl.notes,
        isCustom: false,
      };
    });

    // Criar algumas transações detalhadas para alimentar o histórico
    const transactions: Transaction[] = [];
    const mm = String(m + 1).padStart(2, '0');

    // Transações de exemplo representativas para o mês
    transactions.push(
      {
        id: `tx-${m}-1`,
        date: `${year}-${mm}-05`,
        month: monthIndex,
        year,
        type: 'income',
        group: 'income',
        category: 'Trabalho Principal',
        description: 'Salário Mensal - Depósito em Conta',
        amount: items.find((i) => i.name === 'Salário Líquido')?.actual || 6500,
        paymentMethod: 'transfer',
        status: 'paid',
        budgetItemId: items.find((i) => i.name === 'Salário Líquido')?.id,
      },
      {
        id: `tx-${m}-2`,
        date: `${year}-${mm}-07`,
        month: monthIndex,
        year,
        type: 'expense',
        group: 'fixed',
        category: 'Moradia',
        description: 'Aluguel do Apartamento e Condomínio',
        amount: 1850,
        paymentMethod: 'bank_slip',
        status: 'paid',
        budgetItemId: items.find((i) => i.name.includes('Aluguel'))?.id,
      },
      {
        id: `tx-${m}-3`,
        date: `${year}-${mm}-10`,
        month: monthIndex,
        year,
        type: 'expense',
        group: 'variable',
        category: 'Alimentação',
        description: 'Compras Quinzenais no Supermercado',
        amount: 580,
        paymentMethod: 'debit_card',
        status: 'paid',
        budgetItemId: items.find((i) => i.name.includes('Supermercado'))?.id,
      },
      {
        id: `tx-${m}-4`,
        date: `${year}-${mm}-12`,
        month: monthIndex,
        year,
        type: 'expense',
        group: 'debt',
        category: 'Veículos',
        description: 'Parcela Financiamento Carro + Amortização Extra',
        amount: 650,
        paymentMethod: 'bank_slip',
        status: 'paid',
        budgetItemId: items.find((i) => i.name.includes('Financiamento'))?.id,
      },
      {
        id: `tx-${m}-5`,
        date: `${year}-${mm}-15`,
        month: monthIndex,
        year,
        type: 'expense',
        group: 'savings',
        category: 'Reserva',
        description: 'Aporte Reserva de Emergência (CDB 100% CDI)',
        amount: 500,
        paymentMethod: 'pix',
        status: 'paid',
        budgetItemId: items.find((i) => i.name.includes('Reserva'))?.id,
      },
      {
        id: `tx-${m}-6`,
        date: `${year}-${mm}-18`,
        month: monthIndex,
        year,
        type: 'expense',
        group: 'variable',
        category: 'Transporte',
        description: 'Abastecimento Posto Ipiranga (Gasolina)',
        amount: 195,
        paymentMethod: 'credit_card',
        status: 'paid',
        budgetItemId: items.find((i) => i.name.includes('Combustível'))?.id,
      },
      {
        id: `tx-${m}-7`,
        date: `${year}-${mm}-22`,
        month: monthIndex,
        year,
        type: 'expense',
        group: 'variable',
        category: 'Alimentação',
        description: 'Jantar em Família no Restaurante',
        amount: 210,
        paymentMethod: 'credit_card',
        status: 'paid',
        budgetItemId: items.find((i) => i.name.includes('Restaurante'))?.id,
      }
    );

    months.push({
      month: monthIndex,
      year,
      items,
      transactions,
    });
  }

  return months;
};

export const DEFAULT_CATEGORIES_BY_GROUP: Record<string, string[]> = {
  income: ['Trabalho Principal', 'Serviços', 'Investimentos', 'Renda Extra', 'Benefícios', 'Outras Entradas'],
  fixed: ['Moradia', 'Utilidades', 'Telecom', 'Saúde', 'Educação', 'Seguros', 'Assinaturas', 'Outros Fixos'],
  variable: ['Alimentação', 'Transporte', 'Compras', 'Saúde & Farmácia', 'Lazer & Cultura', 'Vestuário', 'Cuidados Pessoais', 'Pets', 'Outros Gastos'],
  debt: ['Empréstimo Pessoal', 'Financiamento Imobiliário', 'Veículos', 'Cartão de Crédito', 'Cheque Especial', 'Outras Dívidas'],
  savings: ['Reserva de Emergência', 'Investimentos (Ações/FIIs)', 'Renda Fixa / Tesouro', 'Metas & Viagens', 'Previdência Privada', 'Aposentadoria'],
};
