import { BudgetItem, MonthSummary, Transaction } from '../types/finance';

export const formatCurrency = (val: number): string => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(val || 0);
};

export const formatPercent = (val: number): string => {
  return `${(val || 0).toFixed(1).replace('.', ',')}%`;
};

export const formatDateBR = (isoDate: string): string => {
  if (!isoDate) return '';
  const parts = isoDate.split('-');
  if (parts.length === 3) {
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  }
  return isoDate;
};

export const getTodayISO = (): string => {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const calculateSummary = (items: BudgetItem[], transactions: Transaction[]): MonthSummary => {
  let incomePlanned = 0;
  let incomeActual = 0;

  let fixedPlanned = 0;
  let fixedActual = 0;

  let variablePlanned = 0;
  let variableActual = 0;

  let savingsPlanned = 0;
  let savingsActual = 0;

  let debtPlanned = 0;
  let debtActual = 0;
  let debtExtraPaid = 0;

  // Se houver transações vinculadas, elas compõem o real; caso contrário, usa o valor actual de cada item
  // Para precisão: calculamos a soma dos itens
  for (const item of items) {
    // Calculamos o realizado do item somando as transações correspondentes (se existirem) ou usando o item.actual
    const itemTxSum = transactions
      .filter((t) => t.budgetItemId === item.id && t.status === 'paid')
      .reduce((acc, t) => acc + t.amount, 0);

    const actualVal = itemTxSum > 0 ? itemTxSum : (item.actual || 0);

    switch (item.group) {
      case 'income':
        incomePlanned += item.planned || 0;
        incomeActual += actualVal;
        break;
      case 'fixed':
        fixedPlanned += item.planned || 0;
        fixedActual += actualVal;
        break;
      case 'variable':
        variablePlanned += item.planned || 0;
        variableActual += actualVal;
        break;
      case 'savings':
        savingsPlanned += item.planned || 0;
        savingsActual += actualVal;
        break;
      case 'debt':
        debtPlanned += item.planned || 0;
        debtActual += actualVal;
        debtExtraPaid += item.extraPayment || 0;
        break;
    }
  }

  // Se houver transações que não foram atreladas a um item específico do orçamento, soma por grupo
  const unlinkedTxs = transactions.filter((t) => !t.budgetItemId && t.status === 'paid');
  for (const tx of unlinkedTxs) {
    if (tx.type === 'income') {
      incomeActual += tx.amount;
    } else {
      if (tx.group === 'fixed') fixedActual += tx.amount;
      else if (tx.group === 'variable') variableActual += tx.amount;
      else if (tx.group === 'savings') savingsActual += tx.amount;
      else if (tx.group === 'debt') debtActual += tx.amount;
    }
  }

  const incomeDifference = incomeActual - incomePlanned;
  const fixedDifference = fixedPlanned - fixedActual; // Positivo = economizou no orçamento
  const variableDifference = variablePlanned - variableActual; // Positivo = sobrou do orçado
  const savingsDifference = savingsActual - savingsPlanned;
  const debtDifference = debtPlanned - debtActual;

  const totalExpensesPlanned = fixedPlanned + variablePlanned + debtPlanned;
  const totalExpensesActual = fixedActual + variableActual + debtActual + debtExtraPaid;

  const totalOutflowPlanned = totalExpensesPlanned + savingsPlanned;
  const totalOutflowActual = totalExpensesActual + savingsActual;

  // Orçamento Disponível = Receitas Previstas - Total Planejado (se der 0, orçamento é zero-based equilibrado)
  const availableBudget = incomePlanned - totalOutflowPlanned;

  // Disponível para Gastar / Saldo Real = Entradas Efetivas - Saídas Efetivas (o que sobrou na conta bancária)
  const availableToSpend = incomeActual - totalOutflowActual;

  // Orçamento Restante para Gastos (Fixas + Variáveis) = (Orçado Fixas + Variáveis) - (Gasto Fixas + Variáveis)
  const budgetRemainingToSpend = (fixedPlanned + variablePlanned) - (fixedActual + variableActual);

  const savingsRate = incomeActual > 0 ? ((savingsActual + debtExtraPaid) / incomeActual) * 100 : 0;

  return {
    incomePlanned,
    incomeActual,
    incomeDifference,
    fixedPlanned,
    fixedActual,
    fixedDifference,
    variablePlanned,
    variableActual,
    variableDifference,
    savingsPlanned,
    savingsActual,
    savingsDifference,
    debtPlanned,
    debtActual,
    debtExtraPaid,
    debtDifference,
    totalExpensesPlanned,
    totalExpensesActual,
    totalOutflowPlanned,
    totalOutflowActual,
    availableBudget,
    availableToSpend,
    budgetRemainingToSpend,
    savingsRate,
  };
};
